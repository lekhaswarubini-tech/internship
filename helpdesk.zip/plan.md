# Enterprise Chatbot Support System — Implementation Plan

## Product shape

A document-grounded enterprise support workspace with two modes: a polished employee/customer chat surface and an admin command center. The chatbot will only answer from indexed uploaded documents, with citations on every grounded response and a clear escalation path when retrieval confidence is low.

## Implementation approach

- **Runtime:** Node.js HTTP server on port 3000, serving the static frontend and JSON APIs.
- **Persistence:** MySQL-compatible managed database when `DATABASE_URL` is present, with a JSON file fallback for local development continuity. Application tables cover documents, chunks, conversations, messages, feedback, and ingestion events.
- **Knowledge ingestion:** multipart upload for PDF, TXT, and DOCX. Text extraction uses `pdf-parse` for PDF and `mammoth` for DOCX. Documents are chunked into searchable passages and indexed with a deterministic token-overlap / TF-IDF-style scorer.
- **Grounded answering:** query retrieval returns top passages. If the managed LLM service credentials are available, the server sends only those passages plus the question to the LLM with strict grounding instructions. Without LLM credentials, the server returns a concise extractive answer from the retrieved passages. Low-confidence results explicitly say the knowledge base does not contain enough information and offer human support.
- **Admin APIs:** document list, upload, delete, ingestion status, conversation list, feedback, and compact performance statistics.
- **Frontend:** dependency-free HTML/CSS/JavaScript SPA with a sidebar, chat composer, suggested questions, source cards, admin tabs, upload dropzone, conversation table, FAQ frequency list, and performance metrics.
- **Privacy posture:** no hardcoded company policies, no seeded fake conversations, upload validation, file-size limits, safe filename handling, HTML escaping in the client, and server-only platform credentials.

## Project structure

- `server.js` — HTTP server, API routes, retrieval, optional LLM call, persistence adapter, and document ingestion.
- `public/index.html` — application shell and accessible UI markup.
- `public/styles.css` — responsive command-center visual system.
- `public/app.js` — client state, chat interactions, admin views, uploads, and rendering.
- `public/manus-routes.json` — managed route manifest.
- `Dockerfile` — production container entrypoint honoring `PORT`.
- `plan.md` / `TODO.md` — approved scope and delivery state.

## Design direction

Three possible directions were considered: **Quiet operations console** (0.07), **Editorial knowledge atlas** (0.04), and **Neon service cockpit** (0.06). Chosen: **Quiet operations console**.

- **Design Movement:** Modern Swiss information design blended with calm enterprise software ergonomics.
- **Core Principles:** hierarchy before decoration; evidence before confidence; dense but breathable information; fast paths for common support work.
- **Color Philosophy:** midnight navy anchors trust and focus; warm paper surfaces keep long reading comfortable; mint and amber are reserved for system state and attention, not decoration.
- **Layout Paradigm:** a persistent left rail frames a wide working canvas; chat and admin content are organized as offset surfaces with deliberate asymmetry rather than a centered card grid.
- **Signature Elements:** a slim signal rail beside answers; citation chips that look like evidence tags; small uppercase operational labels paired with oversized metric numerals.
- **Interaction Philosophy:** every action acknowledges its state—searching, grounded, needs review, or escalated. The interface never pretends an answer is stronger than its sources.
- **Animation:** quick 160–220ms fades and slide-ins for message arrival, source reveal, and tab changes; no looping decoration; loading states use quiet pulsing bars.
- **Typography System:** Inter/system sans for UI density; serif display accents for high-value page headings; tabular numerals for metrics. Use weight and spacing more than color for hierarchy.
- **Brand Essence:** Support intelligence for teams that need answers they can trust; measured, clear, accountable.
- **Brand Voice:** headlines are direct; microcopy is calm and explicit. Example lines: “Answers with a paper trail.” “No verified source found — route this to a human specialist.”
- **Wordmark & Logo:** a compact “HS” evidence-mark made from two offset brackets, used as a small square mark in the rail.
- **Signature Brand Color:** `#78E4C2` mint, used as the ownable “grounded” signal against navy.

## Build workflow

Implement the server and frontend, install pinned dependencies, start the configured preview listener, verify `/`, `/manus-routes.json`, health, document/chat/stats APIs, and run syntax checks. Then inspect the rendered preview, fix any confirmed issues, commit the complete project to `main`, and leave publication unchanged unless the project’s existing setting explicitly authorizes it.
