const state = { view: 'chat', conversationId: null, busy: false, conversations: [], documents: [], stats: null };
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

async function api(path, options = {}) {
  const response = await fetch(path, { ...options, headers: { ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) } });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || 'Something went wrong.');
  return payload;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' })[character]);
}

function renderRichText(value) {
  return escapeHtml(value).split(/\n\n+/).map((paragraph) => `<p>${paragraph.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')}</p>`).join('');
}

function formatDate(value, withTime = false) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return '—';
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', ...(withTime ? { hour: 'numeric', minute: '2-digit' } : {}) }).format(date);
}

function formatSize(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2800);
}

function setView(view) {
  state.view = view;
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === view));
  $$('.view').forEach((item) => item.classList.toggle('active', item.id === `view-${view}`));
  const title = { chat: 'Ask support', knowledge: 'Knowledge base', conversations: 'Conversations', insights: 'Insights' }[view];
  $('#topbar-title').textContent = title;
  if (view === 'knowledge') loadDocuments();
  if (view === 'conversations') loadConversations();
  if (view === 'insights') loadStats();
}

function updateCounts() {
  $('#nav-doc-count').textContent = String(state.documents.length).padStart(2, '0');
  $('#nav-convo-count').textContent = String(state.conversations.length).padStart(2, '0');
  $('#chat-source-count').textContent = state.documents.length;
  $('#document-count-pill').textContent = `${state.documents.length} ${state.documents.length === 1 ? 'source' : 'sources'}`;
  $('#conversation-count-pill').textContent = `${state.conversations.length} ${state.conversations.length === 1 ? 'conversation' : 'conversations'}`;
}

function documentIcon(extension) {
  return String(extension || '').replace('.', '').toUpperCase() || 'DOC';
}

function renderDocuments() {
  const body = $('#documents-body');
  if (!state.documents.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty-table">No documents yet. Add the first trusted source.</td></tr>';
    updateCounts();
    return;
  }
  body.innerHTML = state.documents.map((document) => `<tr>
    <td><div class="source-name"><span class="file-icon">${escapeHtml(documentIcon(document.extension))}</span><span><strong title="${escapeHtml(document.title)}">${escapeHtml(document.title)}</strong><small>${escapeHtml(document.filename)} · ${formatSize(document.sizeBytes)}</small></span></div></td>
    <td><span class="table-status"><span class="status-dot"></span>${escapeHtml(document.status || 'ready')}</span></td>
    <td>${Number(document.chunkCount || 0)}</td>
    <td>${formatDate(document.uploadedAt)}</td>
    <td><button class="delete-button" data-delete-document="${escapeHtml(document.id)}" title="Delete document" aria-label="Delete ${escapeHtml(document.title)}">×</button></td>
  </tr>`).join('');
  updateCounts();
}

async function loadDocuments() {
  try {
    const payload = await api('/api/documents');
    state.documents = payload.documents || [];
    renderDocuments();
  } catch (error) { showToast(error.message); }
}

function renderConversations() {
  const body = $('#conversations-body');
  if (!state.conversations.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty-table">No conversations yet. Ask the first question from the support view.</td></tr>';
    updateCounts();
    return;
  }
  body.innerHTML = state.conversations.map((conversation) => `<tr>
    <td><span class="history-title" title="${escapeHtml(conversation.title)}">${escapeHtml(conversation.title)}</span></td>
    <td class="history-date">${formatDate(conversation.updatedAt, true)}</td>
    <td>${Number(conversation.messageCount || 0)}</td>
    <td><span class="state-pill">active</span></td>
    <td><button class="open-button" data-open-conversation="${escapeHtml(conversation.id)}">Open →</button></td>
  </tr>`).join('');
  updateCounts();
}

async function loadConversations() {
  try {
    const payload = await api('/api/conversations');
    state.conversations = payload.conversations || [];
    renderConversations();
  } catch (error) { showToast(error.message); }
}

function renderStats() {
  const stats = state.stats || { documents: 0, questions: 0, answers: 0, positive: 0, negative: 0, faqs: [] };
  $('#metric-documents').textContent = stats.documents;
  $('#metric-questions').textContent = stats.questions;
  $('#metric-grounded').textContent = stats.answers;
  const totalFeedback = stats.positive + stats.negative;
  $('#metric-helpfulness').textContent = totalFeedback ? `${Math.round((stats.positive / totalFeedback) * 100)}%` : '—';
  const faqList = $('#faq-list');
  if (!stats.faqs?.length) {
    faqList.innerHTML = '<div class="empty-state-small">Ask questions to build a useful signal.</div>';
    return;
  }
  const max = Math.max(...stats.faqs.map((faq) => Number(faq.count) || 0), 1);
  faqList.innerHTML = stats.faqs.map((faq) => `<div class="faq-row"><div><p title="${escapeHtml(faq.content)}">${escapeHtml(faq.content)}</p><div class="faq-bar"><span style="width:${Math.max(9, (Number(faq.count) / max) * 100)}%"></span></div></div><span class="faq-count">${faq.count}×</span></div>`).join('');
}

async function loadStats() {
  try {
    const payload = await api('/api/stats');
    state.stats = payload.stats;
    renderStats();
  } catch (error) { showToast(error.message); }
}

function setSignal(confidence, status = '') {
  if (confidence == null) {
    $('#signal-value').textContent = '—';
    $('#signal-bar').style.width = '0%';
    $('#signal-caption').textContent = 'Ask a question to see confidence';
    return;
  }
  const percentage = Math.round(Number(confidence) * 100);
  $('#signal-value').textContent = `${percentage}%`;
  $('#signal-bar').style.width = `${percentage}%`;
  $('#signal-caption').textContent = status === 'escalate' ? 'Low signal — human review recommended' : status === 'clarify' ? 'More detail will improve retrieval' : 'Source match strength for this answer';
}

function appendMessage(message, isTyping = false) {
  const stream = $('#message-stream');
  $('#welcome-state')?.remove();
  if (isTyping) {
    const typing = document.createElement('div');
    typing.className = 'message typing-message';
    typing.innerHTML = '<div class="message-avatar">HS</div><div class="message-body"><div class="message-meta">signaldesk <span>searching sources</span></div><div class="message-bubble"><span class="typing-dots"><i></i><i></i><i></i></span></div></div>';
    stream.appendChild(typing);
    stream.scrollTop = stream.scrollHeight;
    return typing;
  }
  const wrapper = document.createElement('div');
  wrapper.className = `message ${message.role === 'user' ? 'user' : 'assistant'}`;
  const citations = message.citations?.length ? `<div class="citation-list">${message.citations.map((citation) => `<span class="citation-chip" title="${escapeHtml(citation.excerpt || citation.filename)}">${escapeHtml(citation.title || citation.filename)}</span>`).join('')}</div>` : '';
  const actions = message.role === 'assistant' ? `<div class="message-actions"><button data-feedback="up" data-message-id="${escapeHtml(message.id)}" title="Helpful">♧ Helpful</button><button data-feedback="down" data-message-id="${escapeHtml(message.id)}" title="Not helpful">◇ Needs work</button></div>` : '';
  wrapper.innerHTML = `<div class="message-avatar">${message.role === 'user' ? 'AK' : 'HS'}</div><div class="message-body"><div class="message-meta">${message.role === 'user' ? 'You' : 'signaldesk'} <span>${formatDate(message.createdAt, true)}</span></div><div class="message-bubble">${renderRichText(message.content)}${citations}</div>${actions}</div>`;
  stream.appendChild(wrapper);
  stream.scrollTop = stream.scrollHeight;
  if (message.role === 'assistant') setSignal(message.confidence, message.status);
}

function resetChat() {
  state.conversationId = null;
  $('#conversation-title').textContent = 'New support conversation';
  $('#conversation-meta').textContent = 'Private workspace · source citations on';
  $('#message-stream').innerHTML = `<div class="welcome-state" id="welcome-state"><div class="welcome-orbit"><div class="orbit-center">⌁</div><span class="orbit-dot dot-a"></span><span class="orbit-dot dot-b"></span><span class="orbit-dot dot-c"></span></div><span class="eyebrow">READY WHEN YOU ARE</span><h2>What do you need to verify?</h2><p>Ask about onboarding, HR policies, IT procedures, leave, attendance, or customer support. I’ll only use indexed company sources.</p><div class="suggestions"><button data-suggestion="How do I get started as a new employee?">New employee onboarding</button><button data-suggestion="Where can I find the leave and attendance policy?">Leave & attendance</button><button data-suggestion="I need help troubleshooting my account.">IT troubleshooting</button></div></div>`;
  setSignal(null);
}

async function sendQuestion(question) {
  if (state.busy || !question.trim()) return;
  state.busy = true;
  const input = $('#question-input');
  input.value = '';
  input.style.height = 'auto';
  appendMessage({ role: 'user', content: question, createdAt: new Date().toISOString() });
  const typing = appendMessage(null, true);
  $('#send-button').disabled = true;
  try {
    const payload = await api('/api/chat', { method: 'POST', body: JSON.stringify({ question, conversationId: state.conversationId }) });
    state.conversationId = payload.conversationId;
    typing.remove();
    appendMessage(payload.message);
    $('#conversation-title').textContent = state.conversationId ? (state.conversations.find((item) => item.id === state.conversationId)?.title || question.slice(0, 54)) : question.slice(0, 54);
    $('#conversation-meta').textContent = 'Private workspace · source citations on';
    await Promise.all([loadConversations(), loadStats()]);
  } catch (error) {
    typing.remove();
    appendMessage({ role: 'assistant', content: `I couldn’t complete that search. ${error.message} Please try again or route this to human support.`, createdAt: new Date().toISOString(), confidence: 0, status: 'escalate' });
  } finally {
    state.busy = false;
    $('#send-button').disabled = false;
    input.focus();
  }
}

async function openConversation(conversationId) {
  try {
    const payload = await api(`/api/conversations/${encodeURIComponent(conversationId)}`);
    state.conversationId = conversationId;
    $('#message-stream').innerHTML = '';
    (payload.messages || []).forEach((message) => appendMessage(message));
    $('#conversation-title').textContent = payload.conversation?.title || 'Support conversation';
    $('#conversation-meta').textContent = 'Conversation history · source citations on';
    setView('chat');
  } catch (error) { showToast(error.message); }
}

async function handleUpload(event) {
  event.preventDefault();
  const file = $('#file-input').files[0];
  if (!file) { $('#upload-error').textContent = 'Choose a PDF, DOCX, or TXT file first.'; return; }
  const button = $('#upload-button');
  const errorNode = $('#upload-error');
  button.disabled = true;
  errorNode.textContent = '';
  $('#index-status').textContent = 'Indexing…';
  const formData = new FormData();
  formData.append('file', file);
  try {
    await api('/api/documents/upload', { method: 'POST', body: formData });
    $('#file-input').value = '';
    $('#upload-queue').textContent = '';
    $('#upload-queue').classList.remove('visible');
    showToast('Source uploaded and indexed.');
    await loadDocuments();
    $('#index-status').textContent = 'Index ready';
  } catch (error) {
    errorNode.textContent = error.message;
    $('#index-status').textContent = 'Index needs attention';
  } finally { button.disabled = false; }
}

function fileSelected(file) {
  if (!file) return;
  $('#upload-queue').textContent = `${file.name} · ${formatSize(file.size)} ready to index`;
  $('#upload-queue').classList.add('visible');
  $('#upload-error').textContent = '';
}

async function handleClick(event) {
  const nav = event.target.closest('[data-view]');
  if (nav) return setView(nav.dataset.view);
  const suggestion = event.target.closest('[data-suggestion]');
  if (suggestion) { $('#question-input').value = suggestion.dataset.suggestion; $('#question-input').focus(); return; }
  const deleteButton = event.target.closest('[data-delete-document]');
  if (deleteButton) {
    if (!window.confirm('Delete this source from the knowledge base?')) return;
    try { await api(`/api/documents/${encodeURIComponent(deleteButton.dataset.deleteDocument)}`, { method: 'DELETE' }); showToast('Source removed from the index.'); await loadDocuments(); } catch (error) { showToast(error.message); }
    return;
  }
  const openButton = event.target.closest('[data-open-conversation]');
  if (openButton) return openConversation(openButton.dataset.openConversation);
  const feedback = event.target.closest('[data-feedback]');
  if (feedback) {
    try { await api('/api/feedback', { method: 'POST', body: JSON.stringify({ messageId: feedback.dataset.messageId, rating: feedback.dataset.feedback }) }); feedback.parentElement.innerHTML = '<span style="color:#2d9e80;font-size:10px">Thanks for the signal.</span>'; await loadStats(); } catch (error) { showToast(error.message); }
    return;
  }
  if (event.target.closest('#new-chat-button')) resetChat();
  if (event.target.closest('#escalate-button')) {
    try {
      await api('/api/escalations', { method: 'POST', body: JSON.stringify({ conversationId: state.conversationId, note: 'Human support requested from the support workspace.' }) });
      showToast('Human support request recorded for follow-up.');
    } catch (error) { showToast(error.message); }
  }
}

$('#chat-form').addEventListener('submit', (event) => { event.preventDefault(); sendQuestion($('#question-input').value.trim()); });
$('#upload-form').addEventListener('submit', handleUpload);
$('#file-input').addEventListener('change', (event) => fileSelected(event.target.files[0]));
$('#question-input').addEventListener('input', (event) => { event.target.style.height = 'auto'; event.target.style.height = `${Math.min(event.target.scrollHeight, 100)}px`; });
$('#question-input').addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('#chat-form').requestSubmit(); } });
$('#dropzone').addEventListener('dragover', (event) => { event.preventDefault(); $('#dropzone').classList.add('dragging'); });
$('#dropzone').addEventListener('dragleave', () => $('#dropzone').classList.remove('dragging'));
$('#dropzone').addEventListener('drop', (event) => { event.preventDefault(); $('#dropzone').classList.remove('dragging'); const file = event.dataTransfer.files[0]; if (file) { const transfer = new DataTransfer(); transfer.items.add(file); $('#file-input').files = transfer.files; fileSelected(file); } });
document.addEventListener('click', handleClick);

async function boot() {
  try {
    const [documents, conversations, stats] = await Promise.all([api('/api/documents'), api('/api/conversations'), api('/api/stats')]);
    state.documents = documents.documents || [];
    state.conversations = conversations.conversations || [];
    state.stats = stats.stats;
    updateCounts();
    renderDocuments();
    renderConversations();
    renderStats();
  } catch (error) { showToast(`Workspace connection issue: ${error.message}`); }
}

boot();
