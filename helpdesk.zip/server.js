import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promises as fs } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import crypto from 'node:crypto';
import pdfParse from 'pdf-parse/lib/pdf-parse.js';
import mammoth from 'mammoth';
import formidable from 'formidable';
import mysql from 'mysql2/promise';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execFileAsync = promisify(execFile);
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const LOCAL_DB_FILE = path.join(DATA_DIR, 'support-data.json');
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_EXTENSIONS = new Set(['.pdf', '.txt', '.docx']);
const STOP_WORDS = new Set('a an and are as at be by for from has have how i in is it me of on or our that the their this to was we what when where which who why with you your can could do does does not tell about please policy process help'.split(' '));

const emptyData = () => ({ documents: [], chunks: [], conversations: [], messages: [], feedback: [], events: [] });
const id = () => crypto.randomUUID();
const isoNow = () => new Date().toISOString();

async function ensureDirs() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
}

function cleanText(value) {
  return String(value || '').replace(/\u0000/g, ' ').replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}

function safeFileName(name) {
  return String(name || 'document').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120) || 'document';
}

function extOf(name) {
  return path.extname(String(name || '')).toLowerCase();
}

function tokenize(text) {
  return cleanText(text).toLowerCase().match(/[a-z0-9][a-z0-9'-]*/g)?.filter((token) => token.length > 1 && !STOP_WORDS.has(token)) || [];
}

function chunkText(text, maxChars = 1100) {
  const paragraphs = cleanText(text).split(/\n{2,}/).map((item) => item.trim()).filter(Boolean);
  const chunks = [];
  let current = '';
  for (const paragraph of paragraphs) {
    const candidate = current ? `${current}\n\n${paragraph}` : paragraph;
    if (candidate.length <= maxChars) {
      current = candidate;
      continue;
    }
    if (current) chunks.push(current);
    if (paragraph.length <= maxChars) {
      current = paragraph;
    } else {
      for (let start = 0; start < paragraph.length; start += maxChars - 160) {
        chunks.push(paragraph.slice(start, start + maxChars).trim());
      }
      current = '';
    }
  }
  if (current) chunks.push(current);
  return chunks.filter((item) => item.length > 20);
}

function excerpt(text, max = 340) {
  const normalized = cleanText(text);
  if (normalized.length <= max) return normalized;
  return `${normalized.slice(0, max - 1).trimEnd()}…`;
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 2 * 1024 * 1024) {
        reject(new Error('Request body is too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error('Request body must be valid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function sendText(res, status, body, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': contentType, 'Cache-Control': 'no-store' });
  res.end(body);
}

class Store {
  constructor() {
    this.pool = null;
    this.local = emptyData();
    this.mode = 'local';
  }

  async init() {
    await ensureDirs();
    if (process.env.DATABASE_URL) {
      try {
        this.pool = mysql.createPool({ uri: process.env.DATABASE_URL, connectionLimit: 5, waitForConnections: true, multipleStatements: true, ssl: { rejectUnauthorized: false } });
        await this.pool.query(`
          CREATE TABLE IF NOT EXISTS documents (
            id VARCHAR(36) PRIMARY KEY, title VARCHAR(255) NOT NULL, filename VARCHAR(255) NOT NULL,
            extension VARCHAR(12) NOT NULL, size_bytes INT NOT NULL, status VARCHAR(24) NOT NULL,
            chunk_count INT NOT NULL DEFAULT 0, uploaded_at DATETIME(3) NOT NULL, error_message TEXT NULL
          );
          CREATE TABLE IF NOT EXISTS chunks (
            id VARCHAR(36) PRIMARY KEY, document_id VARCHAR(36) NOT NULL, chunk_index INT NOT NULL,
            content TEXT NOT NULL, created_at DATETIME(3) NOT NULL, INDEX(document_id)
          );
          CREATE TABLE IF NOT EXISTS conversations (
            id VARCHAR(36) PRIMARY KEY, title VARCHAR(255) NOT NULL, created_at DATETIME(3) NOT NULL,
            updated_at DATETIME(3) NOT NULL, message_count INT NOT NULL DEFAULT 0
          );
          CREATE TABLE IF NOT EXISTS messages (
            id VARCHAR(36) PRIMARY KEY, conversation_id VARCHAR(36) NOT NULL, role VARCHAR(16) NOT NULL,
            content TEXT NOT NULL, citations_json TEXT NULL, confidence DECIMAL(5,4) NULL, status VARCHAR(24) NOT NULL DEFAULT 'grounded', created_at DATETIME(3) NOT NULL,
            INDEX(conversation_id), INDEX(role)
          );
          CREATE TABLE IF NOT EXISTS feedback (
            id VARCHAR(36) PRIMARY KEY, message_id VARCHAR(36) NOT NULL, rating VARCHAR(16) NOT NULL,
            created_at DATETIME(3) NOT NULL, INDEX(message_id)
          );
          CREATE TABLE IF NOT EXISTS events (
            id VARCHAR(36) PRIMARY KEY, event_type VARCHAR(64) NOT NULL, payload_json TEXT NULL,
            created_at DATETIME(3) NOT NULL, INDEX(event_type)
          );
        `);
        const [messageColumns] = await this.pool.query("SHOW COLUMNS FROM messages LIKE 'status'");
        if (!messageColumns.length) await this.pool.query("ALTER TABLE messages ADD COLUMN status VARCHAR(24) NOT NULL DEFAULT 'grounded'");
        this.mode = 'mysql';
        return;
      } catch (error) {
        console.warn(`Managed database unavailable; using local persistence fallback. ${error.message}`);
        this.pool = null;
      }
    }
    try {
      this.local = JSON.parse(await fs.readFile(LOCAL_DB_FILE, 'utf8'));
    } catch {
      await this.persistLocal();
    }
  }

  async persistLocal() {
    await fs.writeFile(LOCAL_DB_FILE, JSON.stringify(this.local, null, 2));
  }

  async listDocuments() {
    if (this.mode === 'mysql') {
      const [rows] = await this.pool.query('SELECT id, title, filename, extension, size_bytes AS sizeBytes, status, chunk_count AS chunkCount, uploaded_at AS uploadedAt, error_message AS errorMessage FROM documents ORDER BY uploaded_at DESC');
      return rows;
    }
    return [...this.local.documents].sort((a, b) => String(b.uploadedAt).localeCompare(String(a.uploadedAt)));
  }

  async saveDocument(document, chunks) {
    if (this.mode === 'mysql') {
      const connection = await this.pool.getConnection();
      try {
        await connection.beginTransaction();
        await connection.execute('INSERT INTO documents (id,title,filename,extension,size_bytes,status,chunk_count,uploaded_at,error_message) VALUES (?,?,?,?,?,?,?,?,?)', [document.id, document.title, document.filename, document.extension, document.sizeBytes, document.status, chunks.length, new Date(document.uploadedAt), document.errorMessage || null]);
        for (const [index, content] of chunks.entries()) {
          await connection.execute('INSERT INTO chunks (id,document_id,chunk_index,content,created_at) VALUES (?,?,?,?,?)', [id(), document.id, index, content, new Date(document.uploadedAt)]);
        }
        await connection.execute('INSERT INTO events (id,event_type,payload_json,created_at) VALUES (?,?,?,?)', [id(), 'document_ingested', JSON.stringify({ documentId: document.id, chunkCount: chunks.length }), new Date(document.uploadedAt)]);
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
      return;
    }
    this.local.documents.push({ ...document, chunkCount: chunks.length });
    this.local.chunks.push(...chunks.map((content, index) => ({ id: id(), documentId: document.id, chunkIndex: index, content, createdAt: document.uploadedAt })));
    this.local.events.push({ id: id(), eventType: 'document_ingested', payload: { documentId: document.id, chunkCount: chunks.length }, createdAt: document.uploadedAt });
    await this.persistLocal();
  }

  async deleteDocument(documentId) {
    if (this.mode === 'mysql') {
      await this.pool.execute('DELETE FROM chunks WHERE document_id = ?', [documentId]);
      await this.pool.execute('DELETE FROM documents WHERE id = ?', [documentId]);
      return;
    }
    this.local.documents = this.local.documents.filter((item) => item.id !== documentId);
    this.local.chunks = this.local.chunks.filter((item) => item.documentId !== documentId);
    await this.persistLocal();
  }

  async listChunks() {
    if (this.mode === 'mysql') {
      const [rows] = await this.pool.query('SELECT c.id, c.document_id AS documentId, c.chunk_index AS chunkIndex, c.content, d.title, d.filename FROM chunks c JOIN documents d ON d.id = c.document_id WHERE d.status = \'ready\' ORDER BY c.document_id, c.chunk_index');
      return rows;
    }
    const byId = new Map(this.local.documents.filter((item) => item.status === 'ready').map((item) => [item.id, item]));
    return this.local.chunks.filter((item) => byId.has(item.documentId)).map((item) => ({ ...item, title: byId.get(item.documentId).title, filename: byId.get(item.documentId).filename }));
  }

  async createConversation(title) {
    const conversation = { id: id(), title: title || 'New support conversation', createdAt: isoNow(), updatedAt: isoNow(), messageCount: 0 };
    if (this.mode === 'mysql') {
      await this.pool.execute('INSERT INTO conversations (id,title,created_at,updated_at,message_count) VALUES (?,?,?,?,?)', [conversation.id, conversation.title, new Date(conversation.createdAt), new Date(conversation.updatedAt), 0]);
      return conversation;
    }
    this.local.conversations.push(conversation);
    await this.persistLocal();
    return conversation;
  }

  async addMessage(message) {
    const record = { ...message, citations: message.citations || [], createdAt: message.createdAt || isoNow() };
    if (this.mode === 'mysql') {
      await this.pool.execute('INSERT INTO messages (id,conversation_id,role,content,citations_json,confidence,status,created_at) VALUES (?,?,?,?,?,?,?,?)', [record.id, record.conversationId, record.role, record.content, JSON.stringify(record.citations), record.confidence ?? null, record.status || 'grounded', new Date(record.createdAt)]);
      await this.pool.execute('UPDATE conversations SET updated_at = ?, message_count = message_count + 1 WHERE id = ?', [new Date(record.createdAt), record.conversationId]);
      return record;
    }
    this.local.messages.push(record);
    const conversation = this.local.conversations.find((item) => item.id === record.conversationId);
    if (conversation) {
      conversation.updatedAt = record.createdAt;
      conversation.messageCount += 1;
    }
    await this.persistLocal();
    return record;
  }

  async listConversations() {
    if (this.mode === 'mysql') {
      const [rows] = await this.pool.query('SELECT id,title,created_at AS createdAt,updated_at AS updatedAt,message_count AS messageCount FROM conversations ORDER BY updated_at DESC LIMIT 50');
      return rows;
    }
    return [...this.local.conversations].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0, 50);
  }

  async getConversation(conversationId) {
    if (this.mode === 'mysql') {
      const [conversations] = await this.pool.execute('SELECT id,title,created_at AS createdAt,updated_at AS updatedAt,message_count AS messageCount FROM conversations WHERE id = ?', [conversationId]);
      const [messages] = await this.pool.execute('SELECT id,conversation_id AS conversationId,role,content,citations_json AS citationsJson,confidence,status,created_at AS createdAt FROM messages WHERE conversation_id = ? ORDER BY created_at ASC', [conversationId]);
      return { conversation: conversations[0] || null, messages: messages.map((item) => ({ ...item, citations: JSON.parse(item.citationsJson || '[]') })) };
    }
    return { conversation: this.local.conversations.find((item) => item.id === conversationId) || null, messages: this.local.messages.filter((item) => item.conversationId === conversationId).sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt))) };
  }

  async addFeedback(messageId, rating) {
    const record = { id: id(), messageId, rating, createdAt: isoNow() };
    if (this.mode === 'mysql') {
      await this.pool.execute('INSERT INTO feedback (id,message_id,rating,created_at) VALUES (?,?,?,?)', [record.id, record.messageId, record.rating, new Date(record.createdAt)]);
      return record;
    }
    this.local.feedback.push(record);
    await this.persistLocal();
    return record;
  }

  async addEvent(eventType, payload) {
    const record = { id: id(), eventType, payload, createdAt: isoNow() };
    if (this.mode === 'mysql') {
      await this.pool.execute('INSERT INTO events (id,event_type,payload_json,created_at) VALUES (?,?,?,?)', [record.id, record.eventType, JSON.stringify(record.payload || {}), new Date(record.createdAt)]);
      return record;
    }
    this.local.events.push(record);
    await this.persistLocal();
    return record;
  }

  async stats() {
    if (this.mode === 'mysql') {
      const [[documents]] = await this.pool.query('SELECT COUNT(*) AS value FROM documents WHERE status=\'ready\'');
      const [[questions]] = await this.pool.query('SELECT COUNT(*) AS value FROM messages WHERE role=\'user\'');
      const [[answers]] = await this.pool.query('SELECT COUNT(*) AS value FROM messages WHERE role=\'assistant\'');
      const [[positive]] = await this.pool.query('SELECT COUNT(*) AS value FROM feedback WHERE rating=\'up\'');
      const [[negative]] = await this.pool.query('SELECT COUNT(*) AS value FROM feedback WHERE rating=\'down\'');
      const [faqRows] = await this.pool.query('SELECT content, COUNT(*) AS count FROM messages WHERE role=\'user\' GROUP BY content ORDER BY count DESC LIMIT 5');
      return { documents: Number(documents.value), questions: Number(questions.value), answers: Number(answers.value), positive: Number(positive.value), negative: Number(negative.value), faqs: faqRows };
    }
    const questions = this.local.messages.filter((item) => item.role === 'user');
    const answers = this.local.messages.filter((item) => item.role === 'assistant');
    const counts = new Map();
    questions.forEach((item) => counts.set(item.content, (counts.get(item.content) || 0) + 1));
    const faqs = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([content, count]) => ({ content, count }));
    return { documents: this.local.documents.filter((item) => item.status === 'ready').length, questions: questions.length, answers: answers.length, positive: this.local.feedback.filter((item) => item.rating === 'up').length, negative: this.local.feedback.filter((item) => item.rating === 'down').length, faqs };
  }
}

const store = new Store();

function scoreChunks(query, chunks) {
  const queryTokens = [...new Set(tokenize(query))];
  if (!queryTokens.length) return [];
  const documentFrequency = new Map();
  for (const chunk of chunks) {
    const present = new Set(tokenize(chunk.content));
    for (const token of present) documentFrequency.set(token, (documentFrequency.get(token) || 0) + 1);
  }
  const total = Math.max(chunks.length, 1);
  return chunks.map((chunk) => {
    const tokens = tokenize(chunk.content);
    const tokenSet = new Set(tokens);
    let score = 0;
    for (const token of queryTokens) {
      if (tokenSet.has(token)) score += Math.log((total + 1) / ((documentFrequency.get(token) || 0) + 1)) + 1;
    }
    const phraseBoost = cleanText(chunk.content).toLowerCase().includes(cleanText(query).toLowerCase()) ? 2 : 0;
    const coverage = queryTokens.filter((token) => tokenSet.has(token)).length / queryTokens.length;
    return { ...chunk, score: score + phraseBoost + coverage };
  }).filter((chunk) => chunk.score > 0).sort((a, b) => b.score - a.score).slice(0, 4);
}

async function callGroundedLlm(question, results) {
  if (!process.env.MANUS_API_URL || !process.env.MANUS_API_KEY || !results.length) return null;
  const context = results.map((item, index) => `[Source ${index + 1}: ${item.title} — ${item.filename}]\n${item.content}`).join('\n\n');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(`${process.env.MANUS_API_URL}/v1/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.MANUS_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...(process.env.MANUS_LLM_MODEL ? { model: process.env.MANUS_LLM_MODEL } : {}),
        messages: [
          { role: 'system', content: 'You are an enterprise support assistant. Answer only from the supplied source passages. Never invent or generalize a company policy. If the passages do not answer the question, say that the knowledge base does not contain enough verified information and recommend human support. Keep the answer concise, practical, and transparent.' },
          { role: 'user', content: `Question: ${question}\n\nVerified source passages:\n${context}` }
        ],
        temperature: 0.1
      }),
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.error) return null;
    const content = payload.choices?.[0]?.message?.content;
    return typeof content === 'string' && content.trim() ? content.trim() : null;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function extractiveAnswer(results) {
  if (!results.length) return 'I couldn’t find a verified answer in the current knowledge base. Please add the relevant policy or route this question to a human support specialist.';
  const best = results[0];
  return `I found relevant guidance in **${best.title}**.\n\n${excerpt(best.content, 720)}\n\nIf this does not resolve your question, please contact a human support specialist so they can verify the latest procedure.`;
}

async function ingestUploadedFile(file) {
  try {
    const filename = safeFileName(file.originalFilename || file.newFilename || 'document');
    const extension = extOf(filename);
    if (!ALLOWED_EXTENSIONS.has(extension)) throw new Error('Only PDF, TXT, and DOCX files are supported.');
    if (Number(file.size || 0) > MAX_FILE_SIZE) throw new Error('Files must be 10 MB or smaller.');
    const buffer = await fs.readFile(file.filepath);
    let extracted = '';
    if (extension === '.pdf') {
      try {
        const parsed = await pdfParse(buffer);
        extracted = parsed.text;
      } catch (pdfError) {
        try {
          const parsed = await execFileAsync('pdftotext', ['-layout', file.filepath, '-'], { maxBuffer: MAX_FILE_SIZE });
          extracted = parsed.stdout;
        } catch {
          throw new Error(`PDF text extraction failed: ${pdfError.message}`);
        }
      }
    } else if (extension === '.docx') {
      const parsed = await mammoth.extractRawText({ buffer });
      extracted = parsed.value;
    } else {
      extracted = buffer.toString('utf8');
    }
    const text = cleanText(extracted);
    if (text.length < 20) throw new Error('The document did not contain enough readable text to index.');
    const document = { id: id(), title: path.basename(filename, extension).replace(/[_-]+/g, ' '), filename, extension, sizeBytes: Number(file.size || buffer.length), status: 'ready', uploadedAt: isoNow(), errorMessage: null };
    const chunks = chunkText(text);
    if (!chunks.length) throw new Error('The document did not contain a searchable passage.');
    await store.saveDocument(document, chunks);
    return { ...document, chunkCount: chunks.length };
  } finally {
    await fs.unlink(file.filepath).catch(() => {});
  }
}

function parseUpload(req) {
  return new Promise((resolve, reject) => {
    const form = formidable({ uploadDir: UPLOAD_DIR, keepExtensions: true, maxFileSize: MAX_FILE_SIZE, multiples: false });
    form.parse(req, (error, fields, files) => {
      if (error) return reject(error);
      const candidate = files.file;
      const file = Array.isArray(candidate) ? candidate[0] : candidate;
      if (!file) return reject(new Error('Choose a PDF, TXT, or DOCX file to upload.'));
      resolve(file);
    });
  });
}

async function handleApi(req, res, url) {
  const pathname = url.pathname;
  if (req.method === 'GET' && pathname === '/api/health') return sendJson(res, 200, { ok: true, mode: store.mode, time: isoNow() });
  if (req.method === 'GET' && pathname === '/api/documents') return sendJson(res, 200, { documents: await store.listDocuments() });
  if (req.method === 'POST' && pathname === '/api/documents/upload') {
    try {
      const file = await parseUpload(req);
      const document = await ingestUploadedFile(file);
      return sendJson(res, 201, { document });
    } catch (error) {
      return sendJson(res, 400, { error: error.message || 'Upload failed.' });
    }
  }
  const documentMatch = pathname.match(/^\/api\/documents\/([^/]+)$/);
  if (req.method === 'DELETE' && documentMatch) {
    await store.deleteDocument(documentMatch[1]);
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'GET' && pathname === '/api/stats') return sendJson(res, 200, { stats: await store.stats() });
  if (req.method === 'GET' && pathname === '/api/conversations') return sendJson(res, 200, { conversations: await store.listConversations() });
  const conversationMatch = pathname.match(/^\/api\/conversations\/([^/]+)$/);
  if (req.method === 'GET' && conversationMatch) return sendJson(res, 200, await store.getConversation(conversationMatch[1]));
  if (req.method === 'POST' && pathname === '/api/chat') {
    let body;
    try { body = await parseJsonBody(req); } catch (error) { return sendJson(res, 400, { error: error.message }); }
    const question = cleanText(body.question).slice(0, 2000);
    if (!question) return sendJson(res, 400, { error: 'Ask a question before sending.' });
    let conversationId = cleanText(body.conversationId);
    if (conversationId) {
      const existing = await store.getConversation(conversationId);
      if (!existing.conversation) conversationId = '';
    }
    if (!conversationId) {
      const conversation = await store.createConversation(excerpt(question, 54));
      conversationId = conversation.id;
    }
    const retrieved = scoreChunks(question, await store.listChunks());
    const confidence = retrieved.length ? Math.min(0.98, Math.max(0.18, retrieved[0].score / 8)) : 0.04;
    let answer;
    let status = 'grounded';
    if (tokenize(question).length < 2) {
      answer = 'Could you add a little more detail so I can search the knowledge base accurately? For example, include the policy area, tool, or process you mean.';
      status = 'clarify';
    } else if (confidence < 0.28) {
      answer = extractiveAnswer([]);
      status = 'escalate';
    } else {
      answer = (await callGroundedLlm(question, retrieved)) || extractiveAnswer(retrieved);
    }
    const citations = retrieved.slice(0, 3).map((item) => ({ id: item.documentId, title: item.title, filename: item.filename, excerpt: excerpt(item.content, 180) }));
    const userMessage = await store.addMessage({ id: id(), conversationId, role: 'user', content: question, citations: [], confidence: null });
    const assistantMessage = await store.addMessage({ id: id(), conversationId, role: 'assistant', content: answer, citations, confidence, status });
    return sendJson(res, 200, { conversationId, message: assistantMessage, userMessage });
  }
  if (req.method === 'POST' && pathname === '/api/escalations') {
    let body;
    try { body = await parseJsonBody(req); } catch (error) { return sendJson(res, 400, { error: error.message }); }
    const note = cleanText(body.note || 'Human support requested from the support workspace.').slice(0, 500);
    return sendJson(res, 201, { escalation: await store.addEvent('human_support_requested', { conversationId: cleanText(body.conversationId), note }) });
  }
  if (req.method === 'POST' && pathname === '/api/feedback') {
    let body;
    try { body = await parseJsonBody(req); } catch (error) { return sendJson(res, 400, { error: error.message }); }
    if (!body.messageId || !['up', 'down'].includes(body.rating)) return sendJson(res, 400, { error: 'Feedback must include a message and use up or down.' });
    return sendJson(res, 201, { feedback: await store.addFeedback(body.messageId, body.rating) });
  }
  return sendJson(res, 404, { error: 'API route not found.' });
}

const MIME_TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };
async function serveStatic(req, res, url) {
  let requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  if (requested.includes('..')) return sendText(res, 403, 'Forbidden');
  const filePath = path.join(PUBLIC_DIR, requested);
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) throw new Error('not file');
    const body = await fs.readFile(filePath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[path.extname(filePath)] || 'application/octet-stream', 'Cache-Control': path.extname(filePath) === '.html' ? 'no-cache' : 'public, max-age=300' });
    return res.end(body);
  } catch {
    return sendText(res, 404, 'Not found');
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET') return sendText(res, 405, 'Method not allowed');
    return await serveStatic(req, res, url);
  } catch (error) {
    console.error(error);
    if (!res.headersSent) sendJson(res, 500, { error: 'Unexpected server error.' });
  }
});

await store.init();
server.listen(PORT, '0.0.0.0', () => console.log(`Enterprise support server listening on http://0.0.0.0:${PORT} (${store.mode} persistence)`));
