export default { logoUrl: "https://cdn.simpleicons.org/chartdotjs/C8F169" };
