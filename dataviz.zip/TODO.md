# TODO — AI-Powered Data Visualization Dashboard

## Real dataset ingestion and preview
- [x] Support CSV, XLSX, XLS, and JSON uploads from a drag-and-drop area and file picker.
- [x] Display dataset name, file size, number of rows, and number of columns after upload.
- [x] Preview the uploaded dataset with readable column headers and rows; the preview label follows the active filtered view.
- [x] Validate file type, malformed/empty inputs, and the 25 MB client-side ceiling gracefully with meaningful error messages and loading feedback.
- [x] Process actual uploaded datasets rather than sample data, fake APIs, or hardcoded chart results.

## Automatic analysis and data quality
- [x] Detect numerical, categorical, date, text, and boolean columns from the uploaded records, including spreadsheet Date objects.
- [x] Identify missing values and duplicate records.
- [x] Calculate mean, median, mode, minimum, maximum, and standard deviation for numeric columns and expose these in the data-quality view.
- [x] Identify supported relationships and conservative increasing/decreasing trends without inventing unsupported statistical relationships.
- [x] Surface highest/lowest values, increasing/decreasing trends, significant correlations, potential outliers, and important data-supported observations.
- [x] Recompute metrics, quality, insights, and chart calculations from the active filtered rows.

## Intelligent chart recommendations and dashboard
- [x] Automatically recommend suitable charts based on column types and relationships.
- [x] Generate bar, line, pie, scatter, histogram, area, heatmap, and box plot visualizations when the dataset supports them.
- [x] Display multiple charts in a responsive dashboard with visualization cards.
- [x] Allow users to select different chart types and customize chart titles, axis labels, and colors.
- [x] Provide filters for columns and values; update charts, metrics, insights, and quality panels dynamically when filters change.
- [x] Support zooming, hovering, and interactive tooltips.

## Export and responsive experience
- [x] Download individual charts as PNG or SVG.
- [x] Export the dashboard as PDF.
- [x] Download the cleaned/filtered dataset as CSV.
- [x] Provide clean, intuitive navigation, professional typography, smooth transitions, and responsive desktop/tablet/mobile layouts.
- [x] Provide light and dark mode.

## Delivery quality
- [x] Include a route manifest at `GET /manus-routes.json` for the application page.
- [x] Register host-managed diagnostics, run type-check/build checks, and verify the Preview service responds on port 3000.
- [ ] Consider code-splitting the Plotly bundle in a later performance pass; the production build succeeds with a large-chunk warning because Plotly is a browser-heavy dependency.
- [x] Save the completed project as a canonical checkpoint with the required project metadata.
