import type { ChartSpec, ColumnProfile, DatasetProfile } from '../types';

export function buildRecommendations(profile: DatasetProfile): ChartSpec[] {
  const numeric = profile.columns.filter((column) => column.type === 'numeric');
  const categorical = profile.columns.filter((column) => column.type === 'categorical' || column.type === 'boolean');
  const dates = profile.columns.filter((column) => column.type === 'date');
  const specs: ChartSpec[] = [];
  const add = (spec: ChartSpec) => { if (!specs.some((item) => item.id === spec.id)) specs.push(spec); };
  const measure = numeric[0];
  const category = categorical.find((column) => column.unique <= 12) ?? categorical[0];
  const date = dates[0];

  if (date && measure) {
    add({ id: 'trend-line', type: 'line', title: `${measure.name} over time`, subtitle: `A time-based view of ${measure.name}`, x: date.name, y: measure.name, priority: 100 });
    add({ id: 'trend-area', type: 'area', title: `${measure.name} — cumulative shape`, subtitle: 'Area makes the change in volume easier to scan', x: date.name, y: measure.name, priority: 84 });
  }
  if (category && measure) {
    add({ id: 'category-bar', type: 'bar', title: `${measure.name} by ${category.name}`, subtitle: 'Compare categories at a glance', x: category.name, y: measure.name, priority: 96 });
    if (category.unique <= 8) add({ id: 'category-pie', type: 'pie', title: `${measure.name} share`, subtitle: `Share of ${measure.name} across ${category.name}`, x: category.name, y: measure.name, priority: 72 });
    add({ id: 'category-box', type: 'box', title: `${measure.name} distribution`, subtitle: `Spread of ${measure.name} by ${category.name}`, x: category.name, y: measure.name, priority: 67 });
  }
  if (numeric.length >= 2) {
    add({ id: 'numeric-scatter', type: 'scatter', title: `${numeric[0].name} vs ${numeric[1].name}`, subtitle: 'Check whether two measures move together', x: numeric[0].name, y: numeric[1].name, priority: 91 });
    add({ id: 'numeric-heatmap', type: 'heatmap', title: 'Numeric relationships', subtitle: 'Correlation matrix across numeric columns', priority: 70 });
  }
  if (measure) add({ id: 'measure-histogram', type: 'histogram', title: `${measure.name} distribution`, subtitle: 'See where the values cluster', x: measure.name, priority: 88 });
  if (!specs.length) {
    const first = profile.columns[0];
    if (first) add({ id: 'values-bar', type: 'bar', title: `Rows by ${first.name}`, subtitle: 'A frequency view of the first categorical field', x: first.name, priority: 40 });
  }
  return specs.sort((a, b) => b.priority - a.priority);
}

export function firstColumnOfType(columns: ColumnProfile[], types: ColumnProfile['type'][]) {
  return columns.find((column) => types.includes(column.type));
}
