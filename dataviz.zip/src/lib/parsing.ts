import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import type { DataRow, ParsedDataset } from '../types';
import { buildProfile } from './profiling';

const SUPPORTED_EXTENSIONS = ['csv', 'xlsx', 'xls', 'json'];

function extensionOf(name: string) {
  return name.toLowerCase().split('.').pop() ?? '';
}

function normalizeKey(value: unknown, fallback: string) {
  const key = String(value ?? '').trim();
  return key || fallback;
}

function normalizeRows(input: unknown[]): DataRow[] {
  if (!Array.isArray(input)) throw new Error('The file must contain an array of row objects.');
  const rows = input
    .filter((row) => row !== null && row !== undefined)
    .map((row, index) => {
      if (typeof row !== 'object' || Array.isArray(row)) {
        throw new Error(`Row ${index + 1} is not an object with named columns.`);
      }
      const result: DataRow = {};
      Object.entries(row as Record<string, unknown>).forEach(([key, value]) => {
        result[normalizeKey(key, `Column ${Object.keys(result).length + 1}`)] = value;
      });
      return result;
    });

  if (!rows.length) throw new Error('No data rows were found in this file.');
  const columns: string[] = [];
  rows.forEach((row) => Object.keys(row).forEach((key) => {
    if (!columns.includes(key)) columns.push(key);
  }));
  return rows.map((row) => columns.reduce<DataRow>((acc, column) => {
    acc[column] = row[column] ?? null;
    return acc;
  }, {}));
}

function parseCsv(text: string): DataRow[] {
  const result = Papa.parse<Record<string, unknown>>(text, {
    header: true,
    skipEmptyLines: 'greedy',
    dynamicTyping: true,
  });
  if (result.errors.length) {
    const first = result.errors[0];
    throw new Error(`Could not read this CSV near row ${first.row ?? 'unknown'}: ${first.message}`);
  }
  return normalizeRows(result.data);
}

function parseWorkbook(buffer: ArrayBuffer): DataRow[] {
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
  const firstSheet = workbook.SheetNames[0];
  if (!firstSheet) throw new Error('The workbook does not contain a worksheet.');
  const sheet = workbook.Sheets[firstSheet];
  return normalizeRows(XLSX.utils.sheet_to_json(sheet, { defval: null, raw: true }));
}

function parseJson(text: string): DataRow[] {
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    throw new Error('This JSON file is not valid JSON.');
  }
  if (Array.isArray(value)) return normalizeRows(value);
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    const candidate = [record.data, record.rows, record.records].find(Array.isArray);
    if (candidate) return normalizeRows(candidate);
    return normalizeRows([record]);
  }
  throw new Error('JSON must contain an array of row objects or a single row object.');
}

export async function parseDataset(file: File): Promise<ParsedDataset> {
  const extension = extensionOf(file.name);
  if (!SUPPORTED_EXTENSIONS.includes(extension)) {
    throw new Error('Unsupported file type. Use CSV, XLSX, XLS, or JSON.');
  }
  if (file.size === 0) throw new Error('This file is empty. Add some rows and try again.');
  if (file.size > 25 * 1024 * 1024) {
    throw new Error('This file is larger than 25 MB. Try a smaller extract for browser analysis.');
  }

  const rows = extension === 'csv'
    ? parseCsv(await file.text())
    : extension === 'json'
      ? parseJson(await file.text())
      : parseWorkbook(await file.arrayBuffer());
  const columns = Object.keys(rows[0] ?? {});
  if (!columns.length) throw new Error('No columns were found in this file.');

  return {
    name: file.name,
    size: file.size,
    rows,
    columns,
    profile: buildProfile(rows, columns),
  };
}
