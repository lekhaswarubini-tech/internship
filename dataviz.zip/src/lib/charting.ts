import type { ChartConfig, DataRow, DatasetProfile } from '../types';
import { valueAsNumber, valueIsMissing } from './profiling';

export const palettes = {
  lime: ['#c8f169', '#637a39', '#dff5a5', '#24321c', '#f0f7d9'],
  indigo: ['#5266d9', '#9da9ff', '#252d72', '#d9dcff', '#767ff0'],
  coral: ['#f47e68', '#ffb3a5', '#a83c2d', '#f8d1c8', '#d95d49'],
} as const;

function label(value: unknown) {
  if (value instanceof Date) return value.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  return valueIsMissing(value) ? 'Unknown' : String(value);
}

function aggregate(rows: DataRow[], groupColumn: string, valueColumn?: string) {
  const map = new Map<string, number>();
  rows.forEach((row) => {
    const key = label(row[groupColumn]);
    const value = valueColumn ? valueAsNumber(row[valueColumn]) : 1;
    if (value !== null) map.set(key, (map.get(key) ?? 0) + value);
  });
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

function numericValues(rows: DataRow[], column?: string) {
  return column ? rows.map((row) => valueAsNumber(row[column])).filter((value): value is number => value !== null) : [];
}

function baseMarker(color: string) {
  return { color, line: { color, width: 1 } };
}

export function chartData(config: ChartConfig, rows: DataRow[], profile: DatasetProfile) {
  const colors = palettes[config.color as keyof typeof palettes] ?? palettes.lime;
  const xProfile = profile.columns.find((column) => column.name === config.x);
  const yProfile = profile.columns.find((column) => column.name === config.y);
  if (config.type === 'heatmap') {
    const numeric = profile.columns.filter((column) => column.type === 'numeric');
    const matrix = numeric.map((left) => numeric.map((right) => {
      const leftValues: number[] = [];
      const rightValues: number[] = [];
      rows.forEach((row) => {
        const a = valueAsNumber(row[left.name]); const b = valueAsNumber(row[right.name]);
        if (a !== null && b !== null) { leftValues.push(a); rightValues.push(b); }
      });
      if (leftValues.length < 3) return 0;
      const meanA = leftValues.reduce((a, b) => a + b, 0) / leftValues.length;
      const meanB = rightValues.reduce((a, b) => a + b, 0) / rightValues.length;
      const numerator = leftValues.reduce((total, value, i) => total + (value - meanA) * (rightValues[i] - meanB), 0);
      const denA = Math.sqrt(leftValues.reduce((total, value) => total + (value - meanA) ** 2, 0));
      const denB = Math.sqrt(rightValues.reduce((total, value) => total + (value - meanB) ** 2, 0));
      return denA && denB ? Number((numerator / (denA * denB)).toFixed(2)) : 0;
    }));
    return [{ type: 'heatmap', z: matrix, x: numeric.map((column) => column.name), y: numeric.map((column) => column.name), colorscale: [[0, '#252d72'], [0.5, '#f5f6f1'], [1, '#c8f169']], zmin: -1, zmax: 1, hovertemplate: '%{y} × %{x}: %{z}<extra></extra>' }];
  }
  if (config.type === 'histogram') {
    return [{ type: 'histogram', x: numericValues(rows, config.x), marker: baseMarker(colors[0]), nbinsx: 16, hovertemplate: '%{x}<extra></extra>' }];
  }
  if (config.type === 'scatter') {
    return [{ type: 'scattergl', mode: 'markers', x: rows.map((row) => valueAsNumber(row[config.x ?? ''])), y: rows.map((row) => valueAsNumber(row[config.y ?? ''])), text: rows.map((row) => `${config.x}: ${label(row[config.x ?? ''])}<br>${config.y}: ${label(row[config.y ?? ''])}`), marker: { color: colors[0], size: 8, opacity: 0.78, line: { color: '#1f2829', width: 1 } }, hovertemplate: '%{text}<extra></extra>' }];
  }
  if (config.type === 'pie') {
    const values = aggregate(rows, config.x ?? '', config.y);
    return [{ type: 'pie', labels: values.map(([key]) => key), values: values.map(([, value]) => value), hole: 0.58, marker: { colors }, textinfo: 'label+percent', textposition: 'outside', hovertemplate: '%{label}: %{value:,.2f}<extra></extra>' }];
  }
  if (config.type === 'box') {
    const grouped = new Map<string, number[]>();
    rows.forEach((row) => {
      const group = label(row[config.x ?? '']); const value = valueAsNumber(row[config.y ?? '']);
      if (value !== null) grouped.set(group, [...(grouped.get(group) ?? []), value]);
    });
    return [...grouped.entries()].slice(0, 24).map(([name, values], index) => ({ type: 'box', y: values, name, marker: { color: colors[index % colors.length] }, boxmean: true, hovertemplate: `${name}<br>%{y}<extra></extra>` }));
  }
  const xColumn = config.x ?? '';
  const yColumn = config.y;
  if (xProfile?.type === 'date') {
    const grouped = aggregate(rows, xColumn, yColumn);
    const sorted = grouped.sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime());
    return [{ type: config.type === 'area' ? 'scatter' : 'scatter', mode: 'lines+markers', x: sorted.map(([key]) => key), y: sorted.map(([, value]) => value), fill: config.type === 'area' ? 'tozeroy' : undefined, fillcolor: config.type === 'area' ? 'rgba(200,241,105,0.22)' : undefined, line: { color: colors[0], width: 3 }, marker: { color: colors[0], size: 6 }, hovertemplate: '%{x}<br>%{y:,.2f}<extra></extra>' }];
  }
  const values = aggregate(rows, xColumn, yColumn);
  if (!values.length && yColumn) return [{ type: 'bar', x: [], y: [], marker: baseMarker(colors[0]) }];
  return [{ type: 'bar', x: values.map(([key]) => key).slice(0, 32), y: values.map(([, value]) => value).slice(0, 32), marker: { color: colors[0], line: { color: '#1f2829', width: 0.5 } }, hovertemplate: '%{x}<br>%{y:,.2f}<extra></extra>' }];
}
