import type { ColumnProfile, ColumnType, Correlation, DataRow, DatasetProfile, Insight, NumericStats } from '../types';
import { buildRecommendations } from './recommendations';

const datePattern = /^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}/;

function isMissing(value: unknown) {
  return value === null || value === undefined || (typeof value === 'string' && value.trim() === '');
}

function asNumber(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'string' || value.trim() === '') return null;
  const normalized = value.replace(/[$,%\s,]/g, '');
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function asDate(value: unknown): Date | null {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value;
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  const text = String(value).trim();
  if (!text || (!datePattern.test(text) && Number.isNaN(Date.parse(text)))) return null;
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function inferType(values: unknown[]): ColumnType {
  const present = values.filter((value) => !isMissing(value));
  if (!present.length) return 'text';
  if (present.every((value) => typeof value === 'boolean' || /^(true|false|yes|no)$/i.test(String(value)))) return 'boolean';
  const numericRate = present.filter((value) => asNumber(value) !== null).length / present.length;
  if (numericRate >= 0.82) return 'numeric';
  const dateRate = present.filter((value) => asDate(value) !== null).length / present.length;
  if (dateRate >= 0.82 && present.some((value) => value instanceof Date || datePattern.test(String(value)))) return 'date';
  const unique = new Set(present.map(String)).size;
  return unique <= Math.min(24, Math.max(6, Math.ceil(present.length * 0.18))) ? 'categorical' : 'text';
}

function quantile(sorted: number[], q: number) {
  if (!sorted.length) return 0;
  const position = (sorted.length - 1) * q;
  const base = Math.floor(position);
  const rest = position - base;
  return sorted[base + 1] === undefined ? sorted[base] : sorted[base] + rest * (sorted[base + 1] - sorted[base]);
}

function getStats(values: unknown[]): NumericStats & { outlierCount: number } {
  const nums = values.map(asNumber).filter((value): value is number => value !== null).sort((a, b) => a - b);
  const sum = nums.reduce((total, value) => total + value, 0);
  const mean = sum / nums.length;
  const median = quantile(nums, 0.5);
  const frequencies = new Map<number, number>();
  nums.forEach((value) => frequencies.set(value, (frequencies.get(value) ?? 0) + 1));
  const maxFrequency = Math.max(...frequencies.values());
  const modeEntry = [...frequencies.entries()].find(([, count]) => count === maxFrequency);
  const variance = nums.reduce((total, value) => total + (value - mean) ** 2, 0) / nums.length;
  const q1 = quantile(nums, 0.25);
  const q3 = quantile(nums, 0.75);
  const iqr = q3 - q1;
  const outlierCount = iqr === 0 ? 0 : nums.filter((value) => value < q1 - 1.5 * iqr || value > q3 + 1.5 * iqr).length;
  return {
    mean, median, mode: maxFrequency > 1 ? modeEntry?.[0] ?? null : null,
    min: nums[0], max: nums[nums.length - 1], stdDev: Math.sqrt(variance), outlierCount,
  };
}

function correlation(left: number[], right: number[]) {
  const n = left.length;
  if (n < 3) return 0;
  const leftMean = left.reduce((a, b) => a + b, 0) / n;
  const rightMean = right.reduce((a, b) => a + b, 0) / n;
  const numerator = left.reduce((total, value, index) => total + (value - leftMean) * (right[index] - rightMean), 0);
  const leftDenominator = Math.sqrt(left.reduce((total, value) => total + (value - leftMean) ** 2, 0));
  const rightDenominator = Math.sqrt(right.reduce((total, value) => total + (value - rightMean) ** 2, 0));
  return leftDenominator && rightDenominator ? numerator / (leftDenominator * rightDenominator) : 0;
}

function buildCorrelations(rows: DataRow[], numericColumns: ColumnProfile[]): Correlation[] {
  const result: Correlation[] = [];
  for (let i = 0; i < numericColumns.length; i += 1) {
    for (let j = i + 1; j < numericColumns.length; j += 1) {
      const left: number[] = [];
      const right: number[] = [];
      rows.forEach((row) => {
        const a = asNumber(row[numericColumns[i].name]);
        const b = asNumber(row[numericColumns[j].name]);
        if (a !== null && b !== null) { left.push(a); right.push(b); }
      });
      const value = correlation(left, right);
      if (Number.isFinite(value) && Math.abs(value) >= 0.35) {
        result.push({
          left: numericColumns[i].name,
          right: numericColumns[j].name,
          value,
          strength: Math.abs(value) >= 0.75 ? 'strong' : Math.abs(value) >= 0.5 ? 'moderate' : 'weak',
        });
      }
    }
  }
  return result.sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
}

function buildInsights(rows: DataRow[], columns: ColumnProfile[], correlations: Correlation[], duplicateRows: number): Insight[] {
  const insights: Insight[] = [];
  const numeric = columns.filter((column) => column.type === 'numeric' && column.stats);
  const dateColumn = columns.find((column) => column.type === 'date');
  const mostMissing = [...columns].sort((a, b) => b.missingPct - a.missingPct)[0];
  if (mostMissing?.missing) {
    insights.push({ id: 'missing', tone: mostMissing.missingPct > 20 ? 'coral' : 'indigo', label: 'DATA QUALITY', title: `${mostMissing.name} needs a closer look`, detail: `${mostMissing.missing.toLocaleString()} of ${mostMissing.total.toLocaleString()} values are missing (${mostMissing.missingPct.toFixed(1)}%).` });
  }
  if (duplicateRows) {
    insights.push({ id: 'duplicates', tone: 'coral', label: 'DATA QUALITY', title: `${duplicateRows.toLocaleString()} duplicate rows detected`, detail: 'These rows are counted, not removed. Download the cleaned view only after reviewing the active filter.' });
  }
  numeric.slice(0, 2).forEach((column) => {
    if (!column.stats) return;
    insights.push({ id: `range-${column.name}`, tone: 'lime', label: 'RANGE', title: `${column.name} spans ${formatCompact(column.stats.min)} to ${formatCompact(column.stats.max)}`, detail: `The median is ${formatCompact(column.stats.median)} with a standard deviation of ${formatCompact(column.stats.stdDev)}.` });
    if (column.outlierCount) insights.push({ id: `outliers-${column.name}`, tone: 'coral', label: 'POTENTIAL OUTLIERS', title: `${column.name} has ${column.outlierCount} IQR outlier${column.outlierCount === 1 ? '' : 's'}`, detail: 'The IQR rule flags these values for review; it does not label them as errors.' });
  });
  const topCorrelation = correlations[0];
  if (topCorrelation) {
    insights.push({ id: 'correlation', tone: 'indigo', label: 'RELATIONSHIP', title: `${topCorrelation.left} and ${topCorrelation.right} move ${topCorrelation.value >= 0 ? 'together' : 'in opposite directions'}`, detail: `Pearson correlation is ${topCorrelation.value.toFixed(2)} (${topCorrelation.strength}). Correlation does not imply causation.` });
  }
  if (dateColumn && numeric[0]) {
    const points = rows.map((row) => ({ date: asDate(row[dateColumn.name]), value: asNumber(row[numeric[0].name]) })).filter((point): point is { date: Date; value: number } => point.date !== null && point.value !== null).sort((a, b) => a.date.getTime() - b.date.getTime());
    if (points.length >= 3) {
      const first = points[0].value;
      const last = points[points.length - 1].value;
      const change = first === 0 ? 0 : (last - first) / Math.abs(first);
      if (Math.abs(change) >= 0.03) {
        const direction = change > 0 ? 'increasing' : 'decreasing';
        insights.push({ id: 'trend', tone: change > 0 ? 'lime' : 'coral', label: 'SUPPORTED TREND', title: `${numeric[0].name} is ${direction} across the time field`, detail: `The first-to-last change is ${(Math.abs(change) * 100).toFixed(1)}% across ${points.length} dated observations. This is a directional read, not a forecast.` });
      }
    }
  }
  if (!insights.length && rows.length) {
    insights.push({ id: 'clean', tone: 'lime', label: 'FIRST READ', title: 'This table is ready to explore', detail: 'No missing values, duplicates, or strong numeric relationships were detected by the current checks.' });
  }
  return insights.slice(0, 6);
}

function formatCompact(value: number) {
  return new Intl.NumberFormat('en-US', { notation: Math.abs(value) >= 1000 ? 'compact' : 'standard', maximumFractionDigits: 2 }).format(value);
}

export function buildProfile(rows: DataRow[], columns: string[]): DatasetProfile {
  const profiles = columns.map<ColumnProfile>((name) => {
    const values = rows.map((row) => row[name]);
    const type = inferType(values);
    const present = values.filter((value) => !isMissing(value));
    const profile: ColumnProfile = {
      name, type, total: values.length, missing: values.length - present.length,
      missingPct: values.length ? ((values.length - present.length) / values.length) * 100 : 0,
      unique: new Set(present.map(String)).size,
      samples: [...new Set(present.map((value) => String(value)))].slice(0, 4),
    };
    if (type === 'numeric') {
      const stats = getStats(values);
      profile.stats = stats;
      profile.outlierCount = stats.outlierCount;
    }
    return profile;
  });
  const duplicateKeys = new Set<string>();
  let duplicateRows = 0;
  rows.forEach((row) => {
    const key = columns.map((column) => JSON.stringify(row[column] ?? null)).join('|');
    if (duplicateKeys.has(key)) duplicateRows += 1;
    duplicateKeys.add(key);
  });
  const numeric = profiles.filter((column) => column.type === 'numeric');
  const correlations = buildCorrelations(rows, numeric);
  const insights = buildInsights(rows, profiles, correlations, duplicateRows);
  const base: DatasetProfile = {
    columns: profiles, rowCount: rows.length, columnCount: columns.length,
    missingCells: profiles.reduce((total, column) => total + column.missing, 0),
    duplicateRows, correlations, insights, recommendations: [],
  };
  base.recommendations = buildRecommendations(base);
  return base;
}

export function valueAsNumber(value: unknown): number | null {
  return asNumber(value);
}

export function valueIsMissing(value: unknown) {
  return isMissing(value);
}
