import { useMemo, useRef, useState } from 'react';
import { Activity, BarChart3, Check, ChevronDown, CircleHelp, Database, Download, FileDown, LayoutDashboard, Moon, RefreshCcw, Rows3, Search, ShieldCheck, Sparkles, Sun, Upload, WandSparkles, X } from 'lucide-react';
import { UploadPanel } from './components/UploadPanel';
import { ChartCard } from './components/ChartCard';
import { DataPreview } from './components/DataPreview';
import { parseDataset } from './lib/parsing';
import { buildProfile } from './lib/profiling';
import { downloadCsv, downloadDashboardPdf } from './lib/export';
import type { ChartConfig, ChartType, FilterState, ParsedDataset } from './types';

const chartTypes: ChartType[] = ['bar', 'line', 'area', 'pie', 'scatter', 'histogram', 'box', 'heatmap'];
const paletteOptions = ['lime', 'indigo', 'coral'] as const;
type View = 'overview' | 'explore' | 'quality' | 'rows';

function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function configFromSpec(spec: ParsedDataset['profile']['recommendations'][number]): ChartConfig {
  return { type: spec.type, title: spec.title, x: spec.x, y: spec.y, group: spec.group, xLabel: spec.x, yLabel: spec.y, color: 'lime' };
}

function App() {
  const [dataset, setDataset] = useState<ParsedDataset | null>(null);
  const [configs, setConfigs] = useState<Record<string, ChartConfig>>({});
  const [selectedChartId, setSelectedChartId] = useState('');
  const [view, setView] = useState<View>('overview');
  const [filter, setFilter] = useState<FilterState>({ column: '', value: '' });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('signalroom-theme') as 'light' | 'dark') || 'light');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const dashboardRef = useRef<HTMLDivElement>(null);

  const loadFile = async (file: File) => {
    setBusy(true); setError('');
    try {
      const parsed = await parseDataset(file);
      const nextConfigs = Object.fromEntries(parsed.profile.recommendations.map((spec) => [spec.id, configFromSpec(spec)]));
      setDataset(parsed); setConfigs(nextConfigs); setSelectedChartId(parsed.profile.recommendations[0]?.id ?? ''); setView('overview'); setFilter({ column: '', value: '' });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Something went wrong while reading this file.');
    } finally { setBusy(false); }
  };

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next); localStorage.setItem('signalroom-theme', next);
  };

  const filteredRows = useMemo(() => {
    if (!dataset || !filter.column || !filter.value) return dataset?.rows ?? [];
    return dataset.rows.filter((row) => String(row[filter.column] ?? 'Unknown') === filter.value);
  }, [dataset, filter]);

  const activeProfile = useMemo(() => {
    if (!dataset) return null;
    return buildProfile(filteredRows, dataset.columns);
  }, [dataset, filteredRows]);

  const filterValues = useMemo(() => {
    if (!dataset || !filter.column) return [];
    return [...new Set(dataset.rows.map((row) => String(row[filter.column] ?? 'Unknown')))].sort((a, b) => a.localeCompare(b)).slice(0, 120);
  }, [dataset, filter.column]);

  const selectedConfig = selectedChartId ? configs[selectedChartId] : undefined;
  const updateSelected = (patch: Partial<ChartConfig>) => {
    if (!selectedChartId) return;
    setConfigs((current) => ({ ...current, [selectedChartId]: { ...current[selectedChartId], ...patch } }));
  };

  const exportPdf = async () => {
    if (dashboardRef.current && dataset) await downloadDashboardPdf(dashboardRef.current, `${dataset.name.replace(/\.[^.]+$/, '')}-signalroom`);
  };

  const nav = [
    { id: 'overview' as const, label: 'Overview', icon: LayoutDashboard },
    { id: 'explore' as const, label: 'Explore charts', icon: BarChart3 },
    { id: 'quality' as const, label: 'Data quality', icon: ShieldCheck },
    { id: 'rows' as const, label: 'Rows', icon: Rows3 },
  ];

  return (
    <div className={`app ${theme}`}>
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><span /><span /><span /></div><span className="brand-name">signalroom</span></div>
        <div className="workspace-label">WORKSPACE <span className="live-dot" /></div>
        <nav>{nav.map(({ id, label, icon: Icon }) => <button key={id} className={view === id ? 'active' : ''} onClick={() => dataset && setView(id)} disabled={!dataset}><Icon size={17} /><span>{label}</span>{view === id && <span className="nav-active" />}</button>)}</nav>
        <div className="sidebar-bottom">
          <div className="privacy-note"><ShieldCheck size={15} /><div><strong>Private by default</strong><span>Your file stays in this browser.</span></div></div>
          {dataset ? <button className="new-file-button" onClick={() => { setDataset(null); setError(''); }}><Upload size={15} /> New dataset</button> : <div className="sidebar-tip"><CircleHelp size={15} /><span>Start with any tidy table.</span></div>}
        </div>
      </aside>
      <main className="main">
        <header className="topbar"><div className="topbar-context"><span className="crumb">SIGNALROOM</span><span className="slash">/</span><span>{dataset ? dataset.name : 'New analysis'}</span></div><div className="topbar-actions"><button className="icon-button" onClick={toggleTheme} title="Toggle light and dark mode" aria-label="Toggle light and dark mode">{theme === 'light' ? <Moon size={17} /> : <Sun size={17} />}</button>{dataset && <><button className="subtle-button" onClick={exportPdf}><FileDown size={15} /> Export PDF</button><button className="primary-button" onClick={() => downloadCsv(filteredRows, dataset.columns, `${dataset.name.replace(/\.[^.]+$/, '')}-cleaned.csv`)}><Download size={15} /> Download CSV</button></>}</div></header>
        {!dataset ? <UploadPanel onFile={loadFile} busy={busy} error={error} /> : <div ref={dashboardRef} className="dashboard-canvas">
          <section className="section-heading"><div><div className="eyebrow"><span className="eyebrow-dot" /> {view === 'overview' ? 'FIRST READ' : view === 'explore' ? 'VISUAL EXPLORER' : view === 'quality' ? 'DATA HEALTH' : 'RAW MATERIAL'}</div><h2>{view === 'overview' ? 'A clear read on your dataset.' : view === 'explore' ? 'Choose the view that answers the question.' : view === 'quality' ? 'Trust the shape of the data.' : 'Inspect every row.'}</h2><p>{view === 'overview' ? 'The system has mapped your columns, checked the edges, and prepared a few useful starting points.' : view === 'explore' ? 'Tune a chart, filter the rows, and let the evidence lead.' : view === 'quality' ? 'Missingness, duplicates, type inference, and numeric spread in one place.' : 'A clean, sortable starting point for your next question.'}</p></div><div className="dataset-chip"><Database size={15} /><span>{dataset.name}</span><small>{formatBytes(dataset.size)}</small></div></section>
          <div className="metric-strip"><Metric label="ROWS" value={activeProfile?.rowCount.toLocaleString() ?? '0'} detail="records in view" /><Metric label="COLUMNS" value={activeProfile?.columnCount.toString() ?? '0'} detail={`${activeProfile?.columns.filter((c) => c.type === 'numeric').length ?? 0} numeric`} /><Metric label="MISSING CELLS" value={activeProfile?.missingCells.toLocaleString() ?? '0'} detail={activeProfile?.missingCells ? 'worth reviewing' : 'none found'} tone={activeProfile?.missingCells ? 'coral' : 'lime'} /><Metric label="DUPLICATES" value={activeProfile?.duplicateRows.toLocaleString() ?? '0'} detail={activeProfile?.duplicateRows ? 'repeat records' : 'none found'} tone={activeProfile?.duplicateRows ? 'coral' : 'lime'} /></div>
          {view === 'overview' && activeProfile && <Overview dataset={dataset} profile={activeProfile} rows={filteredRows} configs={configs} dark={theme === 'dark'} onEdit={(id) => { setSelectedChartId(id); setView('explore'); }} onQuality={() => setView('quality')} />}
          {view === 'explore' && selectedConfig && activeProfile && <Explore dataset={dataset} profile={activeProfile} rows={filteredRows} config={selectedConfig} chartId={selectedChartId} dark={theme === 'dark'} filter={filter} filterValues={filterValues} setFilter={setFilter} updateSelected={updateSelected} setSelectedChartId={setSelectedChartId} configs={configs} />}
          {view === 'quality' && activeProfile && <Quality dataset={dataset} profile={activeProfile} />}
          {view === 'rows' && <Rows dataset={dataset} rows={filteredRows} filter={filter} filterValues={filterValues} setFilter={setFilter} />}
        </div>}
      </main>
    </div>
  );
}

function Metric({ label, value, detail, tone = 'neutral' }: { label: string; value: string; detail: string; tone?: string }) {
  return <div className={`metric metric-${tone}`}><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>;
}

function Overview({ dataset, profile, rows, configs, dark, onEdit, onQuality }: { dataset: ParsedDataset; profile: ParsedDataset['profile']; rows: ParsedDataset['rows']; configs: Record<string, ChartConfig>; dark: boolean; onEdit: (id: string) => void; onQuality: () => void }) {
  const charts = dataset.profile.recommendations.slice(0, 3);
  return <>
    <section className="briefing-panel"><div className="briefing-orbit"><div className="orbit-ring ring-one" /><div className="orbit-ring ring-two" /><div className="orbit-core"><Activity size={25} /></div></div><div className="briefing-text"><div className="card-kicker"><Sparkles size={13} /> SIGNAL BRIEF</div><h3>{dataset.profile.recommendations.length} useful starting views are ready.</h3><p>Signalroom found <strong>{profile.columns.filter((column) => column.type === 'numeric').length} numeric</strong>, <strong>{profile.columns.filter((column) => column.type === 'categorical').length} categorical</strong>, and <strong>{profile.columns.filter((column) => column.type === 'date').length} date</strong> field{profile.columns.filter((column) => column.type === 'date').length === 1 ? '' : 's'} in the current view.</p></div><button className="outline-button" onClick={() => onEdit(charts[0]?.id ?? '')}>Tune the first view <WandSparkles size={15} /></button></section>
    <div className="content-grid charts-overview"><div className="chart-column">{charts.map((spec, index) => <ChartCard key={spec.id} config={configs[spec.id]} rows={rows} profile={profile} dark={dark} featured={index === 0} onEdit={() => onEdit(spec.id)} />)}</div><aside className="insight-column"><InsightPanel insights={profile.insights} /><button className="quality-snapshot" onClick={onQuality}><div><span className="card-kicker"><ShieldCheck size={13} /> QUALITY SNAPSHOT</span><strong>{profile.missingCells || profile.duplicateRows ? 'A few edges to review' : 'Clean enough to explore'}</strong><span>{profile.missingCells ? `${profile.missingCells.toLocaleString()} missing cells` : 'No missing cells detected'} · {profile.duplicateRows.toLocaleString()} duplicate rows</span></div><ChevronDown size={16} /></button></aside></div>
    <DataPreview rows={rows} columns={dataset.columns} />
  </>;
}

function InsightPanel({ insights }: { insights: ParsedDataset['profile']['insights'] }) {
  return <section className="insight-panel"><div className="panel-heading"><div><div className="card-kicker"><Sparkles size={13} /> EVIDENCE-BASED NOTES</div><h3>What stands out</h3></div><span className="panel-count">{insights.length} notes</span></div><div className="insight-list">{insights.map((insight) => <div className={`insight insight-${insight.tone}`} key={insight.id}><span className="insight-marker" /><div><span className="insight-label">{insight.label}</span><strong>{insight.title}</strong><p>{insight.detail}</p></div></div>)}</div></section>;
}

function Explore({ dataset, profile, rows, config, chartId, dark, filter, filterValues, setFilter, updateSelected, setSelectedChartId, configs }: { dataset: ParsedDataset; profile: ParsedDataset['profile']; rows: ParsedDataset['rows']; config: ChartConfig; chartId: string; dark: boolean; filter: FilterState; filterValues: string[]; setFilter: (filter: FilterState) => void; updateSelected: (patch: Partial<ChartConfig>) => void; setSelectedChartId: (id: string) => void; configs: Record<string, ChartConfig> }) {
  return <div className="explorer-layout"><aside className="control-panel"><div className="panel-heading"><div><div className="card-kicker"><WandSparkles size={13} /> CHART BUILDER</div><h3>Shape the question</h3></div></div><label>STARTING VIEW<select value={chartId} onChange={(event) => setSelectedChartId(event.target.value)}>{dataset.profile.recommendations.map((spec) => <option key={spec.id} value={spec.id}>{spec.title}</option>)}</select></label><label>CHART TYPE<select value={config.type} onChange={(event) => updateSelected({ type: event.target.value as ChartType })}>{chartTypes.map((type) => <option key={type} value={type}>{type[0].toUpperCase() + type.slice(1)}</option>)}</select></label><label>X AXIS / GROUP<select value={config.x ?? ''} onChange={(event) => updateSelected({ x: event.target.value || undefined, xLabel: event.target.value || undefined })}><option value="">Automatic</option>{dataset.columns.map((column) => <option key={column} value={column}>{column}</option>)}</select></label><label>Y AXIS / MEASURE<select value={config.y ?? ''} onChange={(event) => updateSelected({ y: event.target.value || undefined, yLabel: event.target.value || undefined })}><option value="">Row count</option>{profile.columns.filter((column) => column.type === 'numeric').map((column) => <option key={column.name} value={column.name}>{column.name}</option>)}</select></label><label>CHART TITLE<input value={config.title} onChange={(event) => updateSelected({ title: event.target.value })} /></label><div className="two-fields"><label>X LABEL<input value={config.xLabel ?? ''} onChange={(event) => updateSelected({ xLabel: event.target.value })} /></label><label>Y LABEL<input value={config.yLabel ?? ''} onChange={(event) => updateSelected({ yLabel: event.target.value })} /></label></div><label>PALETTE<select value={config.color} onChange={(event) => updateSelected({ color: event.target.value })}>{paletteOptions.map((palette) => <option key={palette} value={palette}>{palette[0].toUpperCase() + palette.slice(1)}</option>)}</select></label><div className="filter-control"><div className="control-label"><span>FILTER ROWS</span><button onClick={() => setFilter({ column: '', value: '' })} disabled={!filter.column}><RefreshCcw size={13} /> Clear</button></div><select value={filter.column} onChange={(event) => setFilter({ column: event.target.value, value: '' })}><option value="">No filter</option>{profile.columns.filter((column) => column.type === 'categorical' || column.type === 'boolean').map((column) => <option key={column.name} value={column.name}>{column.name}</option>)}</select>{filter.column && <select value={filter.value} onChange={(event) => setFilter({ ...filter, value: event.target.value })}><option value="">All values</option>{filterValues.map((value) => <option key={value} value={value}>{value}</option>)}</select>}</div><div className="control-note"><ShieldCheck size={14} /><span>All calculations refresh from the rows currently in view. No data leaves this browser.</span></div></aside><div className="explore-canvas"><div className="explore-toolbar"><div><span className="card-kicker"><Activity size={13} /> LIVE VIEW</span><h3>{rows.length.toLocaleString()} rows in the frame</h3></div><div className="active-filter">{filter.column && filter.value ? <><span>{filter.column}: {filter.value}</span><button onClick={() => setFilter({ column: '', value: '' })}><X size={13} /></button></> : <span>All rows</span>}</div></div><ChartCard config={config} rows={rows} profile={profile} dark={dark} featured /><div className="chart-rail"><span>OTHER STARTING VIEWS</span>{dataset.profile.recommendations.filter((spec) => spec.id !== chartId).map((spec) => <button key={spec.id} onClick={() => setSelectedChartId(spec.id)} className={configs[spec.id]?.type === config.type ? 'selected' : ''}>{spec.type}<strong>{spec.title}</strong></button>)}</div></div></div>;
}

function Quality({ dataset, profile }: { dataset: ParsedDataset; profile: ParsedDataset['profile'] }) {
  const sorted = [...profile.columns].sort((a, b) => b.missingPct - a.missingPct);
  return <div className="quality-layout"><section className="quality-main"><div className="quality-intro"><div><div className="card-kicker"><ShieldCheck size={13} /> COLUMN HEALTH</div><h3>Every field gets a read.</h3><p>Types are inferred from the values in your upload. Numeric statistics use non-missing values; potential outliers use the IQR rule.</p></div><div className="health-score"><span>HEALTHY CELLS</span><strong>{profile.rowCount * profile.columnCount ? Math.round(((profile.rowCount * profile.columnCount - profile.missingCells) / (profile.rowCount * profile.columnCount)) * 100) : 0}%</strong></div></div><div className="column-list">{sorted.map((column) => <div className="column-row" key={column.name}><div className="column-name"><span className={`type-dot type-${column.type}`} /><div><strong>{column.name}</strong><span>{column.type} · {column.unique.toLocaleString()} unique</span></div></div><div className="column-bar"><div style={{ width: `${Math.max(2, 100 - column.missingPct)}%` }} /></div><div className="column-missing">{column.missing ? `${column.missing.toLocaleString()} missing` : 'complete'}</div>{column.stats && <div className="column-range">{column.stats.min.toLocaleString()} → {column.stats.max.toLocaleString()}</div>}</div>)}</div></section><aside className="quality-side"><div className="quality-callout"><div className="callout-icon"><Check size={18} /></div><span className="card-kicker">METHOD NOTE</span><h3>Evidence, not guesses.</h3><p>Signalroom only writes an insight when the active data supports it. Correlation is labeled as correlation; an outlier is a review cue, not an error.</p></div><section className="stats-card"><div className="card-kicker"><Activity size={13} /> NUMERIC FIELDS</div>{profile.columns.filter((column) => column.stats).slice(0, 5).map((column) => <div className="stat-line" key={column.name}><span>{column.name}</span><strong>{column.stats?.mean.toLocaleString(undefined, { maximumFractionDigits: 2 })}</strong><small>mean · med {column.stats?.median.toLocaleString(undefined, { maximumFractionDigits: 2 })} · σ {column.stats?.stdDev.toLocaleString(undefined, { maximumFractionDigits: 2 })}{column.stats?.mode !== null ? ` · mode ${column.stats?.mode}` : ''}</small></div>)}</section></aside></div>;
}

function Rows({ dataset, rows, filter, filterValues, setFilter }: { dataset: ParsedDataset; rows: ParsedDataset['rows']; filter: FilterState; filterValues: string[]; setFilter: (filter: FilterState) => void }) {
  return <div className="rows-layout"><section className="rows-toolbar"><div><div className="card-kicker"><Rows3 size={13} /> DATA TABLE</div><h3>{rows.length.toLocaleString()} rows in view</h3></div><div className="row-filter"><Search size={15} /><select value={filter.column} onChange={(event) => setFilter({ column: event.target.value, value: '' })}><option value="">Filter by column</option>{dataset.profile.columns.filter((column) => column.type === 'categorical' || column.type === 'boolean').map((column) => <option key={column.name} value={column.name}>{column.name}</option>)}</select>{filter.column && <select value={filter.value} onChange={(event) => setFilter({ ...filter, value: event.target.value })}><option value="">All values</option>{filterValues.map((value) => <option key={value} value={value}>{value}</option>)}</select>}</div></section><DataPreview rows={rows} columns={dataset.columns} compact={false} /></div>;
}

export default App;
