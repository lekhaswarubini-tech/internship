import { useEffect, useRef } from 'react';
import { Download, Maximize2 } from 'lucide-react';
import Plotly from 'plotly.js-dist-min';
import type { ChartConfig, DataRow, DatasetProfile } from '../types';
import { chartData } from '../lib/charting';

interface ChartCardProps {
  config: ChartConfig;
  rows: DataRow[];
  profile: DatasetProfile;
  dark: boolean;
  featured?: boolean;
  onEdit?: () => void;
}

export function ChartCard({ config, rows, profile, dark, featured = false, onEdit }: ChartCardProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartRows = rows.length ? rows : [];
  useEffect(() => {
    if (!chartRef.current) return;
    const el = chartRef.current;
    const text = dark ? '#f3f5ed' : '#253033';
    const muted = dark ? '#aeb6ae' : '#6e7975';
    const grid = dark ? '#313d3c' : '#e3e7df';
    const layout: Record<string, unknown> = {
      autosize: true,
      height: featured ? 360 : 280,
      margin: { l: 48, r: 24, t: 12, b: 48 },
      paper_bgcolor: 'rgba(0,0,0,0)',
      plot_bgcolor: 'rgba(0,0,0,0)',
      font: { family: 'DM Sans, sans-serif', color: text, size: 11 },
      showlegend: config.type === 'pie' || config.type === 'box',
      legend: { orientation: 'h', y: -0.18, font: { color: muted } },
      hoverlabel: { bgcolor: dark ? '#222b2b' : '#1f2829', font: { color: '#f5f6f1', family: 'DM Sans' } },
      xaxis: { gridcolor: grid, zerolinecolor: grid, tickfont: { color: muted }, title: config.xLabel || config.x || '' },
      yaxis: { gridcolor: grid, zerolinecolor: grid, tickfont: { color: muted }, title: config.yLabel || config.y || '' },
      hovermode: 'closest',
    };
    Plotly.newPlot(el, chartData(config, chartRows, profile), layout, { responsive: true, displaylogo: false, modeBarButtonsToRemove: ['lasso2d', 'select2d', 'autoScale2d'] });
    return () => { if (el) Plotly.purge(el); };
  }, [config, chartRows, profile, dark, featured]);

  const download = async (format: 'png' | 'svg') => {
    if (!chartRef.current) return;
    await Plotly.downloadImage(chartRef.current, { format, filename: config.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'), width: 1400, height: 800, scale: 2 });
  };

  return (
    <article className={`chart-card ${featured ? 'featured' : ''}`}>
      <div className="chart-card-head">
        <div>
          <div className="card-kicker"><span className="signal-rule" /> {config.type.toUpperCase()} VIEW</div>
          <h3>{config.title || 'Untitled chart'}</h3>
          <p>{config.x ? `${config.x}${config.y ? ` · ${config.y}` : ''}` : 'Relationship view'} · {rows.length.toLocaleString()} rows</p>
        </div>
        <div className="chart-actions">
          {onEdit && <button className="icon-button" onClick={onEdit} aria-label="Edit chart" title="Edit chart"><Maximize2 size={15} /></button>}
          <div className="export-menu">
            <button className="icon-button" aria-label="Download chart" title="Download chart"><Download size={15} /></button>
            <div className="export-popover"><button onClick={() => download('png')}>PNG</button><button onClick={() => download('svg')}>SVG</button></div>
          </div>
        </div>
      </div>
      <div className="plot-wrap"><div ref={chartRef} className="plot" /></div>
    </article>
  );
}
