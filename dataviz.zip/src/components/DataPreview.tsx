import { ArrowUpRight, Table2 } from 'lucide-react';
import type { DataRow } from '../types';

interface DataPreviewProps {
  rows: DataRow[];
  columns: string[];
  compact?: boolean;
}

export function DataPreview({ rows, columns, compact = true }: DataPreviewProps) {
  const visibleColumns = columns.slice(0, compact ? 6 : 10);
  const visibleRows = rows.slice(0, compact ? 6 : 18);
  return (
    <section className="preview-card">
      <div className="panel-heading"><div><div className="card-kicker"><Table2 size={13} /> ROW PREVIEW</div><h3>Rows in current view</h3></div><span className="panel-count">{rows.length.toLocaleString()} total</span></div>
      <div className="table-scroll">
        <table><thead><tr>{visibleColumns.map((column) => <th key={column}>{column}</th>)}</tr></thead><tbody>{visibleRows.map((row, index) => <tr key={index}>{visibleColumns.map((column) => <td key={column}>{row[column] === null || row[column] === undefined || row[column] === '' ? <span className="muted-cell">—</span> : String(row[column])}</td>)}</tr>)}</tbody></table>
      </div>
      {(columns.length > visibleColumns.length || rows.length > visibleRows.length) && <div className="table-foot"><span>Showing {visibleRows.length} rows · {visibleColumns.length} columns</span><span>Use Rows to inspect more <ArrowUpRight size={13} /></span></div>}
    </section>
  );
}
