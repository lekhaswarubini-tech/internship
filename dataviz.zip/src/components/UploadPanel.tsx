import { useRef, useState } from 'react';
import { ArrowUpRight, FileSpreadsheet, FileText, UploadCloud } from 'lucide-react';

interface UploadPanelProps {
  onFile: (file: File) => void;
  busy: boolean;
  error: string;
}

export function UploadPanel({ onFile, busy, error }: UploadPanelProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const chooseFile = () => inputRef.current?.click();
  const acceptFile = (file?: File) => { if (file) onFile(file); };

  return (
    <section className="upload-stage">
      <div className="upload-copy">
        <div className="eyebrow"><span className="eyebrow-dot" /> PRIVATE BY DEFAULT</div>
        <h1>Find the signal<br /><em>in your table.</em></h1>
        <p>Drop in a dataset and signalroom will profile it, surface patterns, and shape the clearest view of what matters.</p>
        <div className="supported-files">
          <span><FileText size={14} /> CSV</span>
          <span><FileSpreadsheet size={14} /> XLSX / XLS</span>
          <span><FileText size={14} /> JSON</span>
        </div>
      </div>
      <div
        className={`dropzone ${isDragging ? 'is-dragging' : ''} ${busy ? 'is-busy' : ''}`}
        onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(event) => { event.preventDefault(); setIsDragging(false); acceptFile(event.dataTransfer.files[0]); }}
        onClick={chooseFile}
        role="button"
        tabIndex={0}
        onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') chooseFile(); }}
      >
        <input ref={inputRef} className="file-input" aria-label="Upload CSV XLSX or JSON file" type="file" accept=".csv,.xlsx,.xls,.json,text/csv,application/json" onChange={(event) => acceptFile(event.target.files?.[0])} />
        <div className="dropzone-mark"><UploadCloud size={24} strokeWidth={1.7} /></div>
        <strong>{busy ? 'Reading your dataset…' : 'Drop your file here'}</strong>
        <span>{busy ? 'Profiling columns, checking quality, preparing charts' : 'or click to browse from your computer'}</span>
        <small>Up to 25 MB · stays in this browser</small>
        <div className="dropzone-action"><ArrowUpRight size={16} /> Choose a file</div>
      </div>
      {error && <div className="inline-error" role="alert">{error}</div>}
    </section>
  );
}
