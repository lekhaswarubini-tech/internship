export type ColumnType = 'numeric' | 'categorical' | 'date' | 'text' | 'boolean';

export type ChartType = 'bar' | 'line' | 'pie' | 'scatter' | 'histogram' | 'area' | 'heatmap' | 'box';

export type DataRow = Record<string, unknown>;

export interface NumericStats {
  mean: number;
  median: number;
  mode: number | null;
  min: number;
  max: number;
  stdDev: number;
}

export interface ColumnProfile {
  name: string;
  type: ColumnType;
  total: number;
  missing: number;
  missingPct: number;
  unique: number;
  samples: string[];
  stats?: NumericStats;
  outlierCount?: number;
}

export interface Correlation {
  left: string;
  right: string;
  value: number;
  strength: 'strong' | 'moderate' | 'weak';
}

export interface Insight {
  id: string;
  tone: 'lime' | 'coral' | 'indigo' | 'neutral';
  label: string;
  title: string;
  detail: string;
}

export interface ChartSpec {
  id: string;
  type: ChartType;
  title: string;
  subtitle: string;
  x?: string;
  y?: string;
  group?: string;
  priority: number;
}

export interface DatasetProfile {
  columns: ColumnProfile[];
  rowCount: number;
  columnCount: number;
  missingCells: number;
  duplicateRows: number;
  correlations: Correlation[];
  insights: Insight[];
  recommendations: ChartSpec[];
}

export interface ParsedDataset {
  name: string;
  size: number;
  rows: DataRow[];
  columns: string[];
  profile: DatasetProfile;
}

export interface FilterState {
  column: string;
  value: string;
}

export interface ChartConfig {
  type: ChartType;
  title: string;
  x?: string;
  y?: string;
  group?: string;
  xLabel?: string;
  yLabel?: string;
  color: string;
}
