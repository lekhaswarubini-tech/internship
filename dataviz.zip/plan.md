# AI-Powered Data Visualization Dashboard — Implementation Plan

## Scope and product approach

Build a complete browser-first analytics workspace that accepts real CSV, XLSX, and JSON files and turns them into an explorable dashboard. Processing remains client-side so uploaded data is not sent to a server, previews are fast, and the first release does not require account or database infrastructure. The application will use typed React modules with Vite, Plotly.js for interactive charts, Papa Parse for CSV, SheetJS for XLSX, and jsPDF/html2canvas for dashboard export. No chart values, insights, or relationships will be hardcoded: every displayed result is derived from the active dataset and filter state.

The experience is organized around a left navigation rail and a working canvas: import data, inspect its profile, understand quality, then explore recommended charts and evidence-backed observations. A compact command header exposes the current file, theme, and export actions. Empty, loading, error, and populated states are all intentional.

## Functional architecture

1. **Ingestion and validation**
   - Drag-and-drop and file-picker upload for `.csv`, `.xlsx`, `.xls`, and `.json`.
   - Validate extension, MIME type, empty files, malformed JSON, unsupported workbook shapes, and a safe client-side file-size ceiling with clear errors.
   - Normalize records into an array of row objects while preserving original column order.
   - Track filename, byte size, parsed row count, and column count.

2. **Data profiling**
   - Infer column kinds: numeric, categorical, date, text, and boolean.
   - Compute missing counts/percentages, duplicate-row count, unique counts, and numeric statistics (mean, median, mode, min, max, standard deviation).
   - Parse dates conservatively and only classify as dates when the values are consistently parseable.
   - Compute pairwise Pearson correlations only for numeric columns with enough non-missing observations.
   - Detect trend direction only where a date/order column and numeric measure support it; detect outliers with the IQR rule and always label them as potential outliers.

3. **Recommendation engine**
   - Score candidate visualizations from available column kinds and cardinality.
   - Recommend useful chart configurations, not generic empty chart shells: bar (category + measure), line/area (date/order + measure), scatter (numeric + numeric), histogram (numeric), pie (low-cardinality category + measure), heatmap (numeric correlation matrix), and box plot (category + numeric where supported).
   - Keep the first three recommendations visible in the overview and expose the rest in the chart workspace.

4. **Dashboard interaction**
   - Render Plotly charts with zoom, pan, hover tooltips, responsive sizing, and client-side download controls.
   - Allow chart-type switching where compatible, x/y/group/filter column selection, title editing, label editing, and palette selection.
   - Provide a global categorical filter and a clear-filters action; chart data and metrics recompute when it changes.
   - Export the currently visible chart as PNG or SVG and export the dashboard view as a PDF.
   - Download the filtered/cleaned dataset as CSV.

5. **Insights and quality**
   - Show only derived observations: extrema, missingness, duplicates, supported trends, top correlations, and IQR outlier counts.
   - Use explicit confidence/qualification language such as “in this dataset” and “potential outliers”; do not claim causality.
   - Surface data-quality cards for missing values and duplicates with drill-down friendly labels.

## Project structure

```text
/home/ubuntu/dataviz/
├── plan.md
├── TODO.md
├── package.json
├── tsconfig.json
├── vite.config.ts
├── index.html
├── public/
│   └── manus-routes.json
└── src/
    ├── main.tsx
    ├── App.tsx
    ├── styles.css
    ├── types.ts
    ├── components/
    │   ├── AppShell.tsx
    │   ├── UploadPanel.tsx
    │   ├── DatasetSummary.tsx
    │   ├── DataPreview.tsx
    │   ├── QualityPanel.tsx
    │   ├── InsightPanel.tsx
    │   ├── ChartCard.tsx
    │   ├── ChartWorkspace.tsx
    │   └── EmptyState.tsx
    └── lib/
        ├── parsing.ts
        ├── profiling.ts
        ├── recommendations.ts
        ├── charting.ts
        ├── export.ts
        └── format.ts
```

## Design direction

### Considered styles

- **Editorial Operations Console** — 0.07 probability: a sharp, magazine-like analytics workspace with high-contrast type and disciplined information bands.
- **Soft Glass Observatory** — 0.06 probability: translucent surfaces, atmospheric gradients, and a calm exploratory feel.
- **Monochrome Research Terminal** — 0.05 probability: stark black-and-white hierarchy with technical annotation and dense data readouts.

### Chosen style: Editorial Operations Console

- **Design Movement:** Contemporary editorial dashboard design blended with Swiss information systems: strong alignment, oversized numerical readouts, and quiet utility controls.
- **Core Principles:** Evidence before decoration; hierarchy through scale; dense but breathable information; every interaction should reveal the next useful question.
- **Color Philosophy:** Warm paper/ink neutrals keep the workspace legible, while one ownable electric-lime signal color marks active analysis and positive movement. Muted indigo and coral are reserved for distinct data states, never as random decoration.
- **Layout Paradigm:** A persistent narrow rail anchors navigation while the main canvas uses asymmetrical horizontal bands: a briefing strip, a wide focal chart, and offset supporting panels. Avoid a uniform card grid.
- **Signature Elements:** Lime “live” rule under the active section, small uppercase editorial labels, and chart cards with a slim metadata spine that states the data mapping before the plot.
- **Interaction Philosophy:** Controls stay near the evidence they affect. Changes animate with short fades and layout shifts, and empty states teach the user what file shape will unlock the next surface.
- **Animation:** 160–220ms ease-out transitions for controls and filter changes; charts crossfade rather than jump; upload states use a quiet scanning shimmer; avoid looping motion after content is ready.
- **Typography System:** Use `Space Grotesk` for display numbers and headings, paired with `DM Sans` for controls and body copy. Uppercase micro-labels use letter spacing and a smaller size; numeric metrics use tabular numerals.
- **Brand Essence:** “A calm control room for finding the signal in any table.” Personality: precise, curious, assured.
- **Brand Voice:** Headlines are concise and observational (“Your table has a shape.”). CTAs are direct and encouraging (“Drop a file. See what it knows.”).
- **Wordmark & Logo:** A small stacked mark made from three offset bars that become a rising chart line, paired with the wordmark `signalroom` in a custom-spaced lowercase treatment.
- **Signature Brand Color:** Electric Lime `#C8F169`, used as the unmistakable analysis-active accent.

## Frontend and serving

Use a Vite React TypeScript app served on port 3000 and bound to `0.0.0.0` for Preview. Use static build output in `dist/`. The route manifest will declare the single `/` page before the first dev-server start. The application has no login, secrets, or managed database in this first release. Dependencies will be pinned in `package.json` and installed with the project package manager before the service starts.

## Build workflow

1. Create the package/tooling files and source modules.
2. Register TypeScript diagnostics through the Webdev runtime post-edit configuration.
3. Implement parsing, profiling, recommendations, charts, exports, and the shell in that order so each layer has a stable contract.
4. Start the Vite development service once the meaningful interface exists and verify HTTP readiness plus `/manus-routes.json`.
5. Run type-check/build checks, inspect the rendered Preview when useful, and correct confirmed issues.
6. Update `TODO.md` with evidence-backed completion status, commit the project files to the canonical `main` branch, and confirm the resulting checkpoint.
