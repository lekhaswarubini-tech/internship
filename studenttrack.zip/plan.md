# Student Progress Tracking System — Implementation Plan

## Scope and approach

Build a responsive single-page dashboard for teachers to review and maintain student academic records. The application will use plain HTML, CSS, and JavaScript, with Chart.js loaded from a public CDN for visualizations. Student records, subject scores, attendance, assignment completion, and teacher preferences will persist in `localStorage`; no backend, account system, or external API is needed for this prototype.

The analytics layer will be deterministic and inspectable rather than pretending to be a trained AI model. It will calculate averages, attendance, score deltas, subject gaps, risk flags, trend labels, and an improvement estimate from recent historical values. Every forward-looking value will be labelled as an estimate and accompanied by the logic used (recent trend plus attendance context).

## Information architecture

- **Overview**: summary cards, academic pulse chart, at-risk/high-performer callouts, recent activity.
- **Students**: searchable/filterable student table, add/edit/delete actions, quick status badges.
- **Student detail**: profile, current vs previous scores, subject comparison, attendance, weak areas, recommendations, estimated next-period score.
- **Reports**: class-level comparisons, attendance distribution, subject averages, exportable printable report view.

Navigation will be client-side tab switching without a router because there is one primary dashboard surface. A consistent right-side detail drawer/modal will keep record editing close to the table context.

## Design direction

### Style options (sampled probabilities)

1. **Quiet academic command center** — 0.07: editorial dashboard surfaces, warm paper background, ink navy, mint and coral accents.
2. **Midnight observatory** — 0.05: dark navy canvas, electric cyan data lines, amber risk signals.
3. **Soft civic utility** — 0.08: pale stone panels, cobalt controls, rounded civic-institutional typography.

### Chosen style: Quiet academic command center

- **Design Movement**: modern editorial information design with restrained Swiss-grid discipline and a warm, human school-office tone.
- **Core Principles**: signal over decoration; dense data should still feel calm; every metric needs context; actions stay close to the record they affect.
- **Color Philosophy**: warm parchment reduces sterile enterprise feel; ink navy provides trustworthy contrast; mint denotes healthy momentum; coral marks attention without panic; muted lilac separates analytical layers.
- **Layout Paradigm**: a narrow rail anchors navigation while a wide “working paper” canvas flows from summary to evidence to action. Asymmetric hero/header zones keep the dashboard from becoming a generic card grid.
- **Signature Elements**: oversized serif section labels, thin rule lines like notebook margins, and small rounded “signal chips” that combine a status dot with plain-language meaning.
- **Interaction Philosophy**: filters update instantly; forms use clear defaults; destructive actions require confirmation; analytics explain themselves in tooltips and inline helper copy.
- **Animation**: subtle 160–220ms fades and y-lifts for cards and drawer transitions; chart updates ease rather than snap; no looping motion in the data view.
- **Typography System**: `DM Sans` for UI/data and `DM Serif Display` for page-level editorial headings, with system fallbacks for resilience. Use compact uppercase labels only for metadata.
- **Brand Essence**: “A calmer way to turn student data into the next right teaching move.” Personality: observant, encouraging, practical.
- **Brand Voice**: headlines are concise and teacher-centred; CTAs are direct. Example lines: “See who needs a nudge.” and “Turn this week’s data into a focused next step.”
- **Wordmark & Logo**: a small open-book mark formed from two offset rounded pages with a single upward signal stroke.
- **Signature Brand Color**: `#6F8F83` muted mint, used for healthy progress and the primary data accent.

## Core data model

```js
{
  id: string,
  name: string,
  email: string,
  grade: string,
  avatar: string,
  attendance: { present: number, total: number },
  assignments: { completed: number, total: number },
  subjects: [
    {
      name: string,
      current: number,
      previous: number,
      topics: [{ name: string, score: number }]
    }
  ],
  trend: number[],
  lastUpdated: string
}
```

## Analytics logic

- Current average: mean of subject `current` values.
- Previous average: mean of subject `previous` values.
- Delta: current average minus previous average.
- Attendance percentage: `present / total * 100`.
- Assignment completion: `completed / total * 100`.
- Weak areas: subject/topic scores below 70, sorted from lowest upward.
- High performer: average >= 85 and attendance >= 90.
- At risk: average < 65, attendance < 75, or a negative score delta <= -5.
- Trend: compare the latest two points in the stored `trend` series; label as improving, steady, or needs attention.
- Improvement estimate: latest score + (average recent step * 0.6) + attendance adjustment, clamped to 0–100. UI copy will state “estimate based on recent trend,” not prediction certainty.
- Recommendations: choose targeted guidance from the weakest subject/topic and attendance or assignment context.

## Project structure

- `index.html`: app shell, accessible landmarks, Chart.js CDN, typography imports.
- `styles.css`: design system, responsive layout, components, states, print styles.
- `app.js`: seed data, LocalStorage persistence, analytics, rendering, event handlers, chart lifecycle, modal/drawer forms, report export.
- `public/manus-routes.json`: `/` route declaration required by the managed preview.
- `README.md`: setup, feature, data processing, storage, and limitations documentation.
- `TODO.md`: acceptance outcomes and implementation status.

## Build and delivery workflow

1. Create the plan and acceptance outcomes.
2. Configure host-managed JavaScript/CSS/HTML diagnostics before the first code batch.
3. Implement the shell, data model, analytics helpers, and seeded records.
4. Add charts, filtering, CRUD flows, detail drawer, and report export.
5. Start the port-3000 dev server and verify `/manus-routes.json` and the application response.
6. Run a read-only requirements review, fix confirmed issues, then save a checkpoint to the canonical remote.

## Constraints and transparency

- No fake API integration and no claim of model-generated intelligence.
- All persistence is local to the browser profile using LocalStorage.
- Sample records are clearly marked as demo data and can be reset.
- The app is a working prototype, not a production student information system; it does not include authentication, FERPA/GDPR controls, or multi-user sync.
