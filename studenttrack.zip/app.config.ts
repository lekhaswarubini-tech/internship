export default {
  logoUrl: "https://img.icons8.com/fluency/96/book-reading.png"
};
