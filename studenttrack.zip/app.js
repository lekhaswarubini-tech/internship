const STORAGE_KEY = "nurture-students-v1";
const SUBJECTS = ["Mathematics", "Science", "English", "History"];
const CHART_COLORS = { mint: "#6f8f83", coral: "#df806e", lilac: "#8c80a8", gold: "#c79b4c", ink: "#20343d", line: "#e2e4dd" };

const state = {
  students: [],
  activeView: "overview",
  editingId: null,
  selectedStudentId: null,
  charts: {},
  toastTimer: null,
  storageAvailable: true,
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clamp = (value, min = 0, max = 100) => Math.max(min, Math.min(max, value));
const average = (values) => values.length ? values.reduce((sum, value) => sum + Number(value || 0), 0) / values.length : 0;
const round = (value, digits = 0) => Number(value.toFixed(digits));
const initials = (name) => name.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase();
const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
const formatDate = (value) => new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(new Date(value));

function sampleStudents() {
  return [
    { id: "stu-001", name: "Maya Thompson", email: "maya.thompson@school.edu", grade: "Grade 10", color: "sage", attendance: { present: 47, total: 50 }, assignments: { completed: 18, total: 20 }, subjects: [
      { name: "Mathematics", current: 91, previous: 84, topics: [{ name: "Quadratics", score: 88 }, { name: "Functions", score: 94 }] },
      { name: "Science", current: 87, previous: 82, topics: [{ name: "Cells", score: 90 }, { name: "Lab reports", score: 80 }] },
      { name: "English", current: 94, previous: 90, topics: [{ name: "Analysis", score: 96 }, { name: "Argument", score: 91 }] },
      { name: "History", current: 89, previous: 87, topics: [{ name: "Source work", score: 88 }, { name: "Essays", score: 91 }] },
    ], trend: [82, 84, 85, 87, 88, 90], lastUpdated: "2026-11-10T09:00:00" },
    { id: "stu-002", name: "Noah Williams", email: "noah.williams@school.edu", grade: "Grade 9", color: "lilac", attendance: { present: 44, total: 50 }, assignments: { completed: 16, total: 20 }, subjects: [
      { name: "Mathematics", current: 76, previous: 73, topics: [{ name: "Fractions", score: 68 }, { name: "Equations", score: 80 }] },
      { name: "Science", current: 81, previous: 78, topics: [{ name: "Forces", score: 83 }, { name: "Energy", score: 79 }] },
      { name: "English", current: 79, previous: 77, topics: [{ name: "Grammar", score: 74 }, { name: "Writing", score: 83 }] },
      { name: "History", current: 74, previous: 75, topics: [{ name: "Chronology", score: 72 }, { name: "Evidence", score: 76 }] },
    ], trend: [73, 74, 75, 76, 77, 78], lastUpdated: "2026-11-09T14:30:00" },
    { id: "stu-003", name: "Aisha Patel", email: "aisha.patel@school.edu", grade: "Grade 11", color: "coral", attendance: { present: 38, total: 50 }, assignments: { completed: 13, total: 20 }, subjects: [
      { name: "Mathematics", current: 59, previous: 69, topics: [{ name: "Calculus", score: 54 }, { name: "Algebra", score: 64 }] },
      { name: "Science", current: 67, previous: 72, topics: [{ name: "Genetics", score: 65 }, { name: "Lab reports", score: 69 }] },
      { name: "English", current: 73, previous: 74, topics: [{ name: "Analysis", score: 72 }, { name: "Structure", score: 74 }] },
      { name: "History", current: 65, previous: 70, topics: [{ name: "Essays", score: 62 }, { name: "Research", score: 68 }] },
    ], trend: [72, 70, 68, 66, 64, 63], lastUpdated: "2026-11-10T08:15:00" },
    { id: "stu-004", name: "Ethan Brooks", email: "ethan.brooks@school.edu", grade: "Grade 8", color: "navy", attendance: { present: 49, total: 50 }, assignments: { completed: 20, total: 20 }, subjects: [
      { name: "Mathematics", current: 96, previous: 92, topics: [{ name: "Geometry", score: 97 }, { name: "Patterns", score: 95 }] },
      { name: "Science", current: 92, previous: 89, topics: [{ name: "Systems", score: 93 }, { name: "Experiments", score: 91 }] },
      { name: "English", current: 89, previous: 86, topics: [{ name: "Reading", score: 91 }, { name: "Voice", score: 87 }] },
      { name: "History", current: 94, previous: 90, topics: [{ name: "Civics", score: 95 }, { name: "Sources", score: 92 }] },
    ], trend: [88, 89, 90, 91, 92, 93], lastUpdated: "2026-11-08T16:20:00" },
    { id: "stu-005", name: "Sofia Martinez", email: "sofia.martinez@school.edu", grade: "Grade 10", color: "gold", attendance: { present: 45, total: 50 }, assignments: { completed: 17, total: 20 }, subjects: [
      { name: "Mathematics", current: 82, previous: 77, topics: [{ name: "Statistics", score: 79 }, { name: "Models", score: 85 }] },
      { name: "Science", current: 78, previous: 75, topics: [{ name: "Ecology", score: 76 }, { name: "Data", score: 80 }] },
      { name: "English", current: 84, previous: 80, topics: [{ name: "Analysis", score: 82 }, { name: "Drafting", score: 86 }] },
      { name: "History", current: 80, previous: 79, topics: [{ name: "Revolutions", score: 77 }, { name: "Context", score: 83 }] },
    ], trend: [75, 76, 78, 79, 80, 81], lastUpdated: "2026-11-07T10:45:00" },
    { id: "stu-006", name: "Liam Chen", email: "liam.chen@school.edu", grade: "Grade 12", color: "sage", attendance: { present: 41, total: 50 }, assignments: { completed: 15, total: 20 }, subjects: [
      { name: "Mathematics", current: 68, previous: 65, topics: [{ name: "Proofs", score: 61 }, { name: "Vectors", score: 72 }] },
      { name: "Science", current: 73, previous: 70, topics: [{ name: "Physics", score: 70 }, { name: "Research", score: 76 }] },
      { name: "English", current: 77, previous: 75, topics: [{ name: "Synthesis", score: 74 }, { name: "Rhetoric", score: 80 }] },
      { name: "History", current: 71, previous: 73, topics: [{ name: "Analysis", score: 68 }, { name: "Thesis", score: 75 }] },
    ], trend: [68, 69, 70, 70, 71, 72], lastUpdated: "2026-11-06T12:10:00" },
    { id: "stu-007", name: "Grace Wilson", email: "grace.wilson@school.edu", grade: "Grade 9", color: "lilac", attendance: { present: 48, total: 50 }, assignments: { completed: 19, total: 20 }, subjects: [
      { name: "Mathematics", current: 86, previous: 88, topics: [{ name: "Proportions", score: 85 }, { name: "Graphs", score: 87 }] },
      { name: "Science", current: 84, previous: 86, topics: [{ name: "Matter", score: 83 }, { name: "Methods", score: 85 }] },
      { name: "English", current: 90, previous: 87, topics: [{ name: "Close reading", score: 91 }, { name: "Writing", score: 89 }] },
      { name: "History", current: 88, previous: 90, topics: [{ name: "Maps", score: 86 }, { name: "Arguments", score: 90 }] },
    ], trend: [88, 88, 87, 88, 88, 87], lastUpdated: "2026-11-05T11:30:00" },
    { id: "stu-008", name: "Oliver Jones", email: "oliver.jones@school.edu", grade: "Grade 8", color: "coral", attendance: { present: 36, total: 50 }, assignments: { completed: 12, total: 20 }, subjects: [
      { name: "Mathematics", current: 62, previous: 66, topics: [{ name: "Decimals", score: 59 }, { name: "Geometry", score: 65 }] },
      { name: "Science", current: 64, previous: 68, topics: [{ name: "Observations", score: 61 }, { name: "Matter", score: 67 }] },
      { name: "English", current: 70, previous: 72, topics: [{ name: "Spelling", score: 66 }, { name: "Reading", score: 74 }] },
      { name: "History", current: 60, previous: 64, topics: [{ name: "Timeline", score: 57 }, { name: "Vocabulary", score: 63 }] },
    ], trend: [69, 68, 66, 65, 64, 64], lastUpdated: "2026-11-04T13:00:00" },
  ];
}

function loadStudents() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(stored) && stored.length) return normalizeStudents(stored);
  } catch (error) { state.storageAvailable = false; console.warn("Could not read local student records", error); }
  const seeded = normalizeStudents(sampleStudents());
  saveStudents(seeded, false);
  return seeded;
}

function saveStudents(students, notify = true) {
  state.students = normalizeStudents(students);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.students));
    localStorage.setItem(`${STORAGE_KEY}-saved`, new Date().toISOString());
    state.storageAvailable = true;
  } catch (error) {
    state.storageAvailable = false;
    console.warn("Could not persist student records", error);
  }
  if (notify) { updateSaveStatus(); showToast(state.storageAvailable ? "Student record saved locally" : "Saved for this session; browser storage is unavailable"); }
}

function normalizeStudents(students) {
  return students.map((student) => ({ ...student, subjects: (student.subjects || []).map((subject) => ({ ...subject, test: Number.isFinite(Number(subject.test)) ? Number(subject.test) : Number(subject.current || 0), assignment: Number.isFinite(Number(subject.assignment)) ? Number(subject.assignment) : Number(subject.current || 0), topics: Array.isArray(subject.topics) ? subject.topics : [] })) }));
}

function analytics(student) {
  const current = average(student.subjects.map((subject) => subject.current));
  const previous = average(student.subjects.map((subject) => subject.previous));
  const attendance = student.attendance.total ? (student.attendance.present / student.attendance.total) * 100 : 0;
  const assignments = student.assignments.total ? (student.assignments.completed / student.assignments.total) * 100 : 0;
  const delta = current - previous;
  const recentStep = student.trend.length > 1 ? average(student.trend.slice(-3).map((score, index, arr) => index === 0 ? 0 : score - arr[index - 1]).slice(1)) : delta;
  const estimate = clamp(current + recentStep * .6 + (attendance >= 85 ? 1.5 : attendance < 75 ? -2 : 0));
  const weakAreas = student.subjects.flatMap((subject) => subject.topics.filter((topic) => Number(topic.score) < 70).map((topic) => ({ ...topic, subject: subject.name }))).sort((a, b) => a.score - b.score);
  const lowSubject = [...student.subjects].sort((a, b) => a.current - b.current)[0];
  let status = "steady";
  if (current >= 85 && attendance >= 90 && delta >= 0) status = "strong";
  if (current < 65 || attendance < 75 || delta <= -5) status = "attention";
  const latestStep = student.trend.length > 1 ? student.trend[student.trend.length - 1] - student.trend[student.trend.length - 2] : delta;
  const trend = latestStep >= 2 ? "improving" : latestStep <= -2 ? "declining" : "steady";
  return { current, previous, attendance, assignments, delta, estimate, weakAreas, lowSubject, status, trend, recentStep, latestStep };
}

function statusLabel(status) { return status === "strong" ? "Strong momentum" : status === "attention" ? "Needs attention" : "Steady progress"; }
function statusClass(status) { return `signal-${status}`; }
function trendCopy(trend) { return trend === "improving" ? "Improving" : trend === "declining" ? "Needs attention" : "Steady"; }
function recommendation(student, result) {
  if (result.attendance < 75) return `Start with a quick attendance check-in, then create a predictable catch-up window for ${result.lowSubject.name}.`;
  if (result.assignments < 75) return `Break the next ${result.lowSubject.name} task into two smaller checkpoints and review the first one together.`;
  if (result.weakAreas.length) return `Use a short retrieval practice routine for ${result.weakAreas[0].name} in ${result.weakAreas[0].subject}, then revisit the topic in a week.`;
  if (result.delta > 3) return "Name the strategy behind this improvement and invite the student to use it in their next challenge.";
  return `Ask the student to set one specific goal for ${result.lowSubject.name} before the next assessment.`;
}

function classStats() {
  const results = state.students.map(analytics);
  const avg = average(results.map((item) => item.current));
  const previous = average(results.map((item) => item.previous));
  return { results, avg, previous, delta: avg - previous, attendance: average(results.map((item) => item.attendance)), assignments: average(results.map((item) => item.assignments)), strong: results.filter((item) => item.status === "strong").length, attention: results.filter((item) => item.status === "attention").length };
}

function updateSaveStatus() {
  let savedAt = null;
  try { savedAt = localStorage.getItem(`${STORAGE_KEY}-saved`); } catch (error) { state.storageAvailable = false; }
  const text = state.storageAvailable ? (savedAt ? `Saved ${formatDate(savedAt)}` : "Saved locally") : "Session only";
  const node = $("#saveStatus");
  if (node) node.innerHTML = `<span class="status-dot"></span> ${text}`;
  $("#navStudentCount").textContent = state.students.length;
}

function renderMetrics() {
  const stats = classStats();
  const metrics = [
    { label: "Total students", value: state.students.length, foot: `${stats.attention} need a focused check-in`, icon: "◌", color: "mint" },
    { label: "Class average", value: `${round(stats.avg)}%`, foot: `<strong class="${stats.delta < 0 ? "negative" : ""}">${stats.delta >= 0 ? "+" : ""}${round(stats.delta, 1)} pts</strong> vs previous`, icon: "↗", color: "coral" },
    { label: "Attendance", value: `${round(stats.attendance)}%`, foot: `${stats.attention} students below 75%`, icon: "◷", color: "lilac" },
    { label: "Assignments", value: `${round(stats.assignments)}%`, foot: `${stats.strong} students at full momentum`, icon: "✓", color: "gold" },
  ];
  $("#metricGrid").innerHTML = metrics.map((metric) => `<article class="metric-card"><div class="metric-topline"><span class="metric-label">${metric.label}</span><span class="metric-icon ${metric.color}">${metric.icon}</span></div><strong class="metric-value">${metric.value}</strong><span class="metric-foot">${metric.foot}</span></article>`).join("");
}

function renderInsights() {
  const stats = classStats();
  const top = [...state.students].sort((a, b) => analytics(b).delta - analytics(a).delta)[0];
  const attention = [...state.students].filter((student) => analytics(student).status === "attention").sort((a, b) => analytics(a).current - analytics(b).current)[0];
  const lowestSubject = SUBJECTS.map((name) => ({ name, score: average(state.students.map((student) => student.subjects.find((subject) => subject.name === name)?.current || 0)) })).sort((a, b) => a.score - b.score)[0];
  const insights = [
    { icon: "↗", cls: "", title: `${top?.name || "A learner"} is building momentum`, copy: `Up ${top ? round(analytics(top).delta, 1) : 0} points from the previous assessment.` },
    { icon: "!", cls: "coral-bg", title: `${stats.attention} students need a closer look`, copy: attention ? `${attention.name} combines a ${round(analytics(attention).current)}% average with a ${round(analytics(attention).attendance)}% attendance rate.` : "No immediate attention signals today." },
    { icon: "◌", cls: "lilac-bg", title: `${lowestSubject.name} is the class gap`, copy: `The current class average is ${round(lowestSubject.score)}%. Try a short retrieval practice cycle.` },
  ];
  $("#insightList").innerHTML = insights.map((item) => `<div class="insight-item"><span class="insight-symbol ${item.cls}">${item.icon}</span><div><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.copy)}</p></div></div>`).join("");
  const lift = average(stats.results.map((result) => result.estimate - result.current));
  $("#focusTitle").textContent = stats.attention ? "Start with one small move" : "Your class has momentum";
  $("#focusCopy").textContent = stats.attention ? `A short, specific support plan for ${attention?.name || "the highest-need learner"} will have more impact than a broad catch-up push.` : "Keep the momentum visible by celebrating small improvements alongside final scores.";
  $("#focusLift").textContent = `+${round(lift, 1)} pts`;
}

function chartDefaults() {
  return { responsive: true, maintainAspectRatio: false, animation: { duration: 500 }, plugins: { legend: { display: false }, tooltip: { backgroundColor: "#20343d", padding: 10, titleFont: { family: "DM Sans", size: 11 }, bodyFont: { family: "DM Sans", size: 11 }, displayColors: false } }, scales: { x: { grid: { display: false }, border: { display: false }, ticks: { color: "#9aa29c", font: { family: "DM Sans", size: 10 } } }, y: { beginAtZero: false, min: 45, max: 100, grid: { color: "#eef0eb" }, border: { display: false }, ticks: { color: "#9aa29c", font: { family: "DM Sans", size: 10 }, callback: (value) => `${value}%` } } } };
}

function destroyChart(name) { if (state.charts[name]) { state.charts[name].destroy(); delete state.charts[name]; } }
function renderCharts() {
  if (!window.Chart) return;
  const stats = classStats();
  const trendLength = Math.max(...state.students.map((student) => student.trend.length), 6);
  const labels = Array.from({ length: trendLength }, (_, index) => `Check ${index + 1}`);
  const classTrend = labels.map((_, index) => average(state.students.map((student) => student.trend[index] ?? student.trend[student.trend.length - 1])));
  destroyChart("trend");
  state.charts.trend = new Chart($("#trendChart"), { type: "line", data: { labels, datasets: [{ data: classTrend, borderColor: CHART_COLORS.mint, backgroundColor: "rgba(111,143,131,.12)", fill: true, borderWidth: 2, pointRadius: 3, pointBackgroundColor: CHART_COLORS.mint, tension: .38 }] }, options: { ...chartDefaults(), plugins: { ...chartDefaults().plugins, tooltip: { ...chartDefaults().plugins.tooltip, callbacks: { label: (context) => ` ${round(context.raw, 1)}% class average` } } } } });
  const subjectScores = SUBJECTS.map((name) => average(state.students.map((student) => student.subjects.find((subject) => subject.name === name)?.current || 0)));
  destroyChart("subject");
  state.charts.subject = new Chart($("#subjectChart"), { type: "bar", data: { labels: SUBJECTS.map((subject) => subject.replace("Mathematics", "Math")), datasets: [{ data: subjectScores, backgroundColor: [CHART_COLORS.mint, CHART_COLORS.lilac, CHART_COLORS.coral, CHART_COLORS.gold], borderRadius: 6, barThickness: 17 }] }, options: { ...chartDefaults(), scales: { ...chartDefaults().scales, y: { ...chartDefaults().scales.y, min: 50 } }, plugins: { ...chartDefaults().plugins, tooltip: { ...chartDefaults().plugins.tooltip, callbacks: { label: (context) => ` ${round(context.raw)}% average` } } } } });
  const distribution = [state.students.filter((student) => analytics(student).attendance >= 90).length, state.students.filter((student) => analytics(student).attendance >= 75 && analytics(student).attendance < 90).length, state.students.filter((student) => analytics(student).attendance < 75).length];
  destroyChart("attendance");
  state.charts.attendance = new Chart($("#attendanceChart"), { type: "doughnut", data: { labels: ["90%+", "75–89%", "Below 75%"], datasets: [{ data: distribution, backgroundColor: [CHART_COLORS.mint, CHART_COLORS.gold, CHART_COLORS.coral], borderWidth: 0, spacing: 3 }] }, options: { responsive: true, maintainAspectRatio: false, cutout: "73%", plugins: { legend: { display: false }, tooltip: { backgroundColor: "#20343d", padding: 10, displayColors: false } } } });
  $("#attendanceCenter").textContent = `${round(stats.attendance)}%`;
  $("#attendanceLegend").innerHTML = [["mint", "90%+", distribution[0]], ["gold", "75–89%", distribution[1]], ["coral", "Below 75%", distribution[2]]].map(([color, label, value]) => `<div class="legend-item"><span class="mini-dot ${color}"></span>${label}<strong>${value}</strong></div>`).join("");

  destroyChart("reportSubject");
  state.charts.reportSubject = new Chart($("#reportSubjectChart"), { type: "bar", data: { labels: SUBJECTS.map((subject) => subject.replace("Mathematics", "Math")), datasets: [{ label: "Current", data: SUBJECTS.map((name) => average(state.students.map((student) => student.subjects.find((subject) => subject.name === name)?.current || 0))), backgroundColor: CHART_COLORS.mint, borderRadius: 5, barThickness: 16 }, { label: "Previous", data: SUBJECTS.map((name) => average(state.students.map((student) => student.subjects.find((subject) => subject.name === name)?.previous || 0))), backgroundColor: "#d9d6e5", borderRadius: 5, barThickness: 16 }] }, options: { ...chartDefaults(), scales: { ...chartDefaults().scales, x: { ...chartDefaults().scales.x, stacked: false }, y: { ...chartDefaults().scales.y, min: 50 } }, plugins: { ...chartDefaults().plugins, legend: { display: true, position: "bottom", labels: { usePointStyle: true, pointStyle: "rectRounded", boxWidth: 7, color: "#76817d", font: { family: "DM Sans", size: 10 } } }, tooltip: { ...chartDefaults().plugins.tooltip } } } });
}

function renderStudentTable() {
  const query = $("#studentSearch").value.trim().toLowerCase();
  const status = $("#statusFilter").value;
  const grade = $("#gradeFilter").value;
  const filtered = state.students.filter((student) => { const result = analytics(student); return (!query || `${student.name} ${student.email}`.toLowerCase().includes(query)) && (status === "all" || result.status === status) && (grade === "all" || student.grade === grade); });
  $("#studentTableTitle").textContent = `${filtered.length} student${filtered.length === 1 ? "" : "s"}`;
  $("#emptyStudents").hidden = filtered.length > 0;
  $("#studentTableBody").innerHTML = filtered.map((student) => { const result = analytics(student); return `<tr data-student-id="${student.id}"><td><div class="student-cell"><span class="avatar ${student.color}">${initials(student.name)}</span><div><strong>${escapeHtml(student.name)}</strong><span>${escapeHtml(student.email)}</span></div></div></td><td>${escapeHtml(student.grade)}</td><td class="number-cell">${round(result.current)}%</td><td>${round(result.attendance)}%</td><td>${round(result.assignments)}%</td><td><span class="signal-chip ${statusClass(result.status)}"><span class="mini-dot ${result.status === "attention" ? "coral" : result.status === "strong" ? "mint" : "lilac"}"></span>${statusLabel(result.status)}</span></td><td><button class="row-action" type="button" aria-label="Open ${escapeHtml(student.name)}">›</button></td></tr>`; }).join("");
}

function renderGradeFilter() {
  const current = $("#gradeFilter").value || "all";
  const grades = [...new Set(state.students.map((student) => student.grade))].sort();
  $("#gradeFilter").innerHTML = `<option value="all">All grades</option>${grades.map((grade) => `<option value="${escapeHtml(grade)}">${escapeHtml(grade)}</option>`).join("")}`;
  $("#gradeFilter").value = grades.includes(current) ? current : "all";
}

function renderReports() {
  const stats = classStats();
  const highestAverage = stats.results.length ? Math.max(...stats.results.map((result) => result.current)) : 0;
  const largestLift = stats.results.length ? Math.max(...stats.results.map((result) => result.delta)) : 0;
  const reportStats = [
    ["Students reviewed", state.students.length, "All active records"],
    ["Highest average", `${round(highestAverage)}%`, "Current period"],
    ["Largest lift", `${largestLift >= 0 ? "+" : ""}${round(largestLift, 1)} pts`, "Since last assessment"],
    ["Needs support", stats.attention, "Based on current signals"],
  ];
  $("#reportStatGrid").innerHTML = reportStats.map(([label, value, note]) => `<div class="report-stat"><p class="eyebrow">${label}</p><strong>${value}</strong><span>${note}</span></div>`).join("");
  const ranked = [...state.students].sort((a, b) => analytics(b).current - analytics(a).current);
  $("#reportTableBody").innerHTML = ranked.map((student, index) => { const result = analytics(student); return `<tr data-student-id="${student.id}"><td class="number-cell">${String(index + 1).padStart(2, "0")}</td><td><div class="student-cell"><span class="avatar ${student.color}">${initials(student.name)}</span><div><strong>${escapeHtml(student.name)}</strong><span>${escapeHtml(student.grade)}</span></div></div></td><td class="number-cell">${round(result.current)}%</td><td class="${result.delta >= 0 ? "delta-up" : "delta-down"}">${result.delta >= 0 ? "+" : ""}${round(result.delta, 1)} pts</td><td class="number-cell">${round(result.estimate)}% <span class="muted-copy">est.</span></td><td><span class="signal-chip ${statusClass(result.status)}">${statusLabel(result.status)}</span></td></tr>`; }).join("");
}

function renderAll() {
  renderMetrics(); renderInsights(); renderGradeFilter(); renderStudentTable(); renderReports(); renderCharts(); updateSaveStatus();
  if (state.selectedStudentId) renderDetail(state.selectedStudentId);
}

function setView(view) {
  state.activeView = view;
  $$("[data-view-panel]").forEach((panel) => panel.classList.toggle("is-visible", panel.dataset.viewPanel === view));
  $$(".nav-item").forEach((item) => item.classList.toggle("is-active", item.dataset.view === view));
  const titles = { overview: ["Teacher workspace / overview", "Good morning, Ms. Carter."], students: ["Teacher workspace / students", "Your learners, in context."], reports: ["Teacher workspace / reports", "A report worth discussing."] };
  $("#pageKicker").textContent = titles[view][0]; $("#pageTitle").textContent = titles[view][1];
  $("#sidebar").classList.remove("is-open");
  if (view === "reports") requestAnimationFrame(renderCharts);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function showToast(message) { const toast = $("#toast"); $("#toastMessage").textContent = message; toast.classList.add("is-visible"); clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2600); }

function buildSubjectInputs(student = null) {
  $("#subjectInputs").innerHTML = SUBJECTS.map((name) => { const subject = student?.subjects.find((item) => item.name === name); const topics = subject?.topics?.map((topic) => `${topic.name}:${topic.score}`).join(", ") || ""; return `<div class="subject-form-row"><span class="subject-name">${name}</span><input class="current-score" data-subject="${name}" type="number" min="0" max="100" step="1" required value="${subject?.current ?? 75}" aria-label="Current ${name} score" /><input class="previous-score" data-subject="${name}" type="number" min="0" max="100" step="1" required value="${subject?.previous ?? 72}" aria-label="Previous ${name} score" /><input class="test-score" data-subject="${name}" type="number" min="0" max="100" step="1" required value="${subject?.test ?? subject?.current ?? 75}" aria-label="Test ${name} score" /><input class="assignment-score" data-subject="${name}" type="number" min="0" max="100" step="1" required value="${subject?.assignment ?? subject?.current ?? 75}" aria-label="Assignment ${name} grade" /><input class="topic-input" data-subject="${name}" type="text" placeholder="e.g. Fractions:62, Equations:74" value="${escapeHtml(topics)}" aria-label="${name} topic notes" /></div>`; }).join("");
}

function openStudentModal(student = null) {
  state.editingId = student?.id || null;
  $("#modalTitle").textContent = student ? "Edit student record" : "Add a new student";
  $("#studentId").value = student?.id || ""; $("#studentName").value = student?.name || ""; $("#studentEmail").value = student?.email || ""; $("#studentGrade").value = student?.grade || "Grade 8"; $("#studentColor").value = student?.color || "sage";
  $("#presentDays").value = student?.attendance.present ?? 45; $("#totalDays").value = student?.attendance.total ?? 50; $("#completedAssignments").value = student?.assignments.completed ?? 16; $("#totalAssignments").value = student?.assignments.total ?? 20;
  buildSubjectInputs(student); $("#formError").hidden = true; $("#studentModal").hidden = false; document.body.style.overflow = "hidden"; setTimeout(() => $("#studentName").focus(), 50);
}
function closeStudentModal() { $("#studentModal").hidden = true; if ($( "#detailDrawer").hidden) document.body.style.overflow = ""; state.editingId = null; }

function parseTopics(raw) { return raw.split(",").map((part) => part.trim()).filter(Boolean).map((part) => { const pieces = part.split(":"); const score = Number(pieces.pop()); return { name: pieces.join(":").trim() || "Topic", score: Number.isFinite(score) ? clamp(score) : 70 }; }); }
function handleStudentSubmit(event) { event.preventDefault(); const form = event.currentTarget; const getNumber = (selector) => Number($(selector).value); const present = getNumber("#presentDays"); const total = getNumber("#totalDays"); const completed = getNumber("#completedAssignments"); const assignmentTotal = getNumber("#totalAssignments"); const name = $("#studentName").value.trim(); const error = $("#formError");
  if (!form.checkValidity() || !name || total < 1 || present > total || assignmentTotal < 1 || completed > assignmentTotal) { error.textContent = !name ? "Please enter the student's full name." : "Please check the required fields. Present days cannot exceed total days, and completed assignments cannot exceed the total."; error.hidden = false; return; }
  const subjects = SUBJECTS.map((subjectName) => { const current = Number($(`.current-score[data-subject="${subjectName}"]`).value); const previous = Number($(`.previous-score[data-subject="${subjectName}"]`).value); const test = Number($(`.test-score[data-subject="${subjectName}"]`).value); const assignment = Number($(`.assignment-score[data-subject="${subjectName}"]`).value); return { name: subjectName, current: clamp(current), previous: clamp(previous), test: clamp(test), assignment: clamp(assignment), topics: parseTopics($(`.topic-input[data-subject="${subjectName}"]`).value) }; });
  const wasEditing = Boolean(state.editingId); const oldStudent = state.students.find((student) => student.id === state.editingId); const currentAverage = average(subjects.map((subject) => subject.current)); const previousAverage = average(subjects.map((subject) => subject.previous)); const trend = oldStudent?.trend || [round(previousAverage - 2), round(previousAverage - 1), round(previousAverage), round((previousAverage + currentAverage) / 2), round(currentAverage - 1), round(currentAverage)]; const student = { id: state.editingId || `stu-${Date.now()}`, name, email: $("#studentEmail").value.trim(), grade: $("#studentGrade").value, color: $("#studentColor").value, attendance: { present, total }, assignments: { completed, total: assignmentTotal }, subjects, trend, lastUpdated: new Date().toISOString() };
  const students = state.editingId ? state.students.map((item) => item.id === state.editingId ? student : item) : [student, ...state.students]; saveStudents(students); closeStudentModal(); renderAll(); setView("students"); showToast(wasEditing ? "Student record updated" : "Student added to the class list");
}

function renderDetail(studentId) { const student = state.students.find((item) => item.id === studentId); if (!student) return; state.selectedStudentId = studentId; const result = analytics(student); const weakest = result.weakAreas.slice(0, 4); $("#detailContent").innerHTML = `<div class="drawer-profile"><span class="avatar ${student.color}">${initials(student.name)}</span><div><h2 id="detailName">${escapeHtml(student.name)}</h2><p>${escapeHtml(student.grade)} · Updated ${formatDate(student.lastUpdated)}</p></div><span class="signal-chip ${statusClass(result.status)} drawer-signal">${statusLabel(result.status)}</span></div><div class="profile-stat-row"><div class="profile-stat"><span>Current avg.</span><strong>${round(result.current)}%</strong></div><div class="profile-stat"><span>Change</span><strong class="${result.delta >= 0 ? "delta-up" : "delta-down"}">${result.delta >= 0 ? "+" : ""}${round(result.delta, 1)}</strong></div><div class="profile-stat"><span>Attendance</span><strong>${round(result.attendance)}%</strong></div></div><div class="drawer-section"><div class="drawer-section-heading"><h3>Subject view</h3><span>Current score</span></div><div class="profile-bars">${student.subjects.map((subject) => `<div class="profile-bar-row"><label>${escapeHtml(subject.name.replace("Mathematics", "Math"))}</label><div class="bar-track"><div class="bar-fill ${subject.current < 70 ? "low" : subject.current < 80 ? "mid" : ""}" style="width:${subject.current}%"></div></div><span class="bar-score">${subject.current}%</span></div>`).join("")}</div></div><div class="drawer-section"><div class="drawer-section-heading"><h3>Progress context</h3><span>Current vs previous</span></div><div class="comparison-card"><div class="comparison-row"><span>Assignments completed</span><strong>${round(result.assignments)}%</strong></div><div class="comparison-row"><span>Previous average</span><strong>${round(result.previous)}%</strong></div><div class="comparison-row"><span>Trend label</span><strong>${trendCopy(result.trend)}</strong></div></div></div><div class="drawer-section"><div class="drawer-section-heading"><h3>Learning gaps</h3><span>${weakest.length ? "Prioritize these" : "No scores below 70"}</span></div>${weakest.length ? `<div class="weak-topic-list">${weakest.map((topic) => `<span class="topic-chip">${escapeHtml(topic.name)} · ${topic.score}%</span>`).join("")}</div>` : `<div class="recommendation-card"><strong>Keep extending the challenge</strong><p>This learner has no topic scores below 70%. Invite them to explain their strategy to a peer.</p></div>`}</div><div class="drawer-section"><div class="drawer-section-heading"><h3>Recommended next step</h3><span>Rule-based guidance</span></div><div class="recommendation-card"><strong>Try this next</strong><p>${escapeHtml(recommendation(student, result))}</p></div><div class="estimate-card"><p>Estimated next-period score<br /><span>Based on recent trend</span></p><strong>${round(result.estimate)}%</strong></div></div>`; $("#detailDrawer").hidden = false; $("#drawerBackdrop").hidden = false; document.body.style.overflow = "hidden"; }
function closeDrawer() { $("#detailDrawer").hidden = true; $("#drawerBackdrop").hidden = true; state.selectedStudentId = null; if ($( "#studentModal").hidden) document.body.style.overflow = ""; }

function exportReport() { const rows = [["Student", "Email", "Grade", "Current average", "Previous average", "Change", "Attendance", "Assignments", "Estimated next", "Signal"]]; state.students.forEach((student) => { const result = analytics(student); rows.push([student.name, student.email, student.grade, round(result.current), round(result.previous), round(result.delta, 1), round(result.attendance), round(result.assignments), round(result.estimate), statusLabel(result.status)]); }); const csv = rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n"); const blob = new Blob([csv], { type: "text/csv;charset=utf-8" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `nurture-class-report-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); URL.revokeObjectURL(url); showToast("Report downloaded as CSV"); }
function resetDemoData() { if (!window.confirm("Reset all records to the original demo data? Any local changes will be removed.")) return; saveStudents(sampleStudents()); renderAll(); showToast("Demo data restored"); }

function bindEvents() {
  $$(".nav-item").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
  $$('[data-view-link]').forEach((button) => button.addEventListener("click", () => setView(button.dataset.viewLink)));
  $("#openStudentsBtn").addEventListener("click", () => setView("students"));
  $("#addStudentTop").addEventListener("click", () => openStudentModal()); $("#addStudentBtn").addEventListener("click", () => openStudentModal());
  $("#studentForm").addEventListener("submit", handleStudentSubmit); $("#resetDataBtn").addEventListener("click", resetDemoData); $("#downloadReportBtn").addEventListener("click", exportReport); $("#printReportBtn").addEventListener("click", () => { setView("reports"); window.print(); });
  $("#studentSearch").addEventListener("input", renderStudentTable); $("#statusFilter").addEventListener("change", renderStudentTable); $("#gradeFilter").addEventListener("change", renderStudentTable);
  $("#mobileMenuBtn").addEventListener("click", () => $("#sidebar").classList.toggle("is-open")); $("#closeDrawerBtn").addEventListener("click", closeDrawer); $("#drawerBackdrop").addEventListener("click", closeDrawer);
  $("#editStudentBtn").addEventListener("click", () => { const student = state.students.find((item) => item.id === state.selectedStudentId); if (student) { closeDrawer(); openStudentModal(student); } });
  $("#deleteStudentBtn").addEventListener("click", () => { const student = state.students.find((item) => item.id === state.selectedStudentId); if (!student || !window.confirm(`Delete ${student.name}'s record? This cannot be undone.`)) return; saveStudents(state.students.filter((item) => item.id !== student.id)); closeDrawer(); renderAll(); showToast("Student record deleted"); });
  $$('[data-close-modal]').forEach((button) => button.addEventListener("click", closeStudentModal));
  $("#studentModal").addEventListener("click", (event) => { if (event.target === $("#studentModal")) closeStudentModal(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") { if (!$("#studentModal").hidden) closeStudentModal(); else if (!$("#detailDrawer").hidden) closeDrawer(); } });
  document.addEventListener("click", (event) => { const row = event.target.closest("tr[data-student-id]"); if (row && !event.target.closest("button")) renderDetail(row.dataset.studentId); const action = event.target.closest(".row-action"); if (action && row) renderDetail(row.dataset.studentId); });
}

function init() { state.students = loadStudents(); bindEvents(); renderAll(); setView("overview"); }
window.addEventListener("DOMContentLoaded", init);
