# Nurture — Student Progress Tracking System

Nurture is a working single-page teacher dashboard for monitoring student performance, attendance, assignment completion, progress trends, learning gaps, and recommended next steps.

## Technologies

The prototype uses semantic HTML, responsive CSS, and vanilla JavaScript. Chart.js powers the line, bar, doughnut, and grouped comparison charts. Google Fonts supplies `DM Sans` and `DM Serif Display`; system fallbacks keep the layout readable if the font request is unavailable. Records persist in the browser with `localStorage`, so no server, account system, or external API is required.

## Features

The Overview page summarizes total students, class average, attendance, assignment completion, subject averages, attendance distribution, class trend, and teacher focus signals. The Students page supports search, grade and signal filtering, row-level detail views, adding, editing, and deleting records. Each subject record captures current and previous marks plus a test score, assignment grade, and optional topic scores. A student detail drawer shows subject bars, previous/current comparisons, weak topics, a targeted recommendation, and an estimated next-period score. The Reports page contains a print-friendly class summary and a CSV download.

Sample records are seeded automatically on the first load. The “Reset demo data” action restores those records and removes local changes.

## Transparent analytics logic

The analytics are deterministic rules, not a claimed machine-learning model:

- Current and previous averages are means of the four subject scores.
- Attendance is `present / total * 100`.
- Assignment completion is `completed / total * 100`.
- Weak areas are topics below 70, sorted from lowest upward.
- “Strong momentum” requires an average of at least 85, attendance of at least 90%, and a non-negative score change.
- “Needs attention” is triggered by an average below 65, attendance below 75%, or a score change of -5 points or lower.
- Trend labels compare the latest two stored checkpoints: a change of at least 2 points is improving, a change of -2 points or lower needs attention, and the rest is steady.
- The improvement value is an estimate: current average plus 60% of the recent trend step, with a small attendance adjustment, clamped to 0–100.

The interface labels estimates as estimates and explains that they are directional, not promises. Recommendations select a practical next step from the learner’s weakest topic, attendance, assignment completion, or positive trend context.

## Run locally

From the project directory, start any static server on port 3000. For example:

```bash
python3 -m http.server 3000
```

Then open `http://localhost:3000` in a browser. Because the app is static, it can also be hosted through any static website service. The managed project preview uses the same port.

## Data and privacy limitations

This prototype stores data only in the current browser profile. It does not provide authentication, multi-user sync, database backups, audit logs, or production-grade student privacy controls such as FERPA/GDPR workflows. For real school use, add a secure backend, role-based access, encryption, consent and retention policies, validation, and an auditable data model before entering real student data.
