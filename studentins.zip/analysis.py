"""Validated, explainable analytics for student assessment data.

No scores are predicted. All reported values are aggregates of uploaded records.
"""
from __future__ import annotations

import re
from typing import Any

import numpy as np
import pandas as pd

ALIASES = {
    "student_id": {"studentid", "student_id", "learnerid", "learner_id", "rollno", "rollnumber", "registrationnumber", "admissionnumber", "id"},
    "student_name": {"studentname", "student_name", "learnername", "learner_name", "name"},
    "subject": {"subject", "course", "coursename", "module"},
    "topic": {"topic", "unit", "chapter", "learningobjective"},
    "score": {"score", "marks", "mark", "overallscore", "examscore", "exammarks", "finalscore", "gradepoints"},
    "assignment_score": {"assignmentscore", "assignment_score", "assignmentmarks", "homeworkscore", "homeworkmarks"},
    "test_score": {"testscore", "test_score", "quizscore", "quizmarks", "testscores"},
    "attendance": {"attendance", "attendancepercent", "attendancepercentage", "attendance_rate", "attendancepct"},
    "term": {"term", "semester", "period", "quarter", "year", "academicterm", "assessmentperiod"},
    "date": {"date", "assessmentdate", "examdate", "recordeddate"},
}
SCORE_FIELDS = ["Score", "Assignment_Score", "Test_Score"]


class DataValidationError(ValueError):
    """Raised when a file cannot be mapped to a usable student dataset."""


def _key(label: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(label).strip().lower())


def _display_id(value: Any) -> str:
    if pd.isna(value):
        return ""
    text = str(value).strip()
    return re.sub(r"\.0$", "", text) if re.fullmatch(r"\d+\.0", text) else text


def _numeric(series: pd.Series) -> pd.Series:
    cleaned = series.astype("string").str.strip().str.replace("%", "", regex=False).str.replace(",", "", regex=False)
    return pd.to_numeric(cleaned, errors="coerce")


def normalize_dataset(raw: pd.DataFrame, score_max: float = 100.0) -> tuple[pd.DataFrame, list[str]]:
    """Map common column names, validate ranges, normalize marks to percentages.

    Long format: one record per student/subject/period (or assessment).
    Wide format: one row per student and numeric subject columns.
    Available Score, Assignment_Score, and Test_Score components are averaged
    with equal weight for each row; available components only are used.
    """
    if raw is None or raw.empty:
        raise DataValidationError("The uploaded file has no data rows.")
    if not np.isfinite(score_max) or score_max <= 0:
        raise DataValidationError("Maximum score must be a positive number.")
    frame = raw.copy()
    frame.columns = [str(c).strip() for c in frame.columns]
    if any(not str(c).strip() or str(c).lower().startswith("unnamed:") for c in frame.columns):
        frame = frame.loc[:, [not str(c).lower().startswith("unnamed:") and str(c).strip() for c in frame.columns]]
    if frame.empty or len(frame.columns) == 0:
        raise DataValidationError("No usable columns were found in this file.")

    mapping: dict[str, str] = {}
    normalized_keys: dict[str, str] = {}
    for col in frame.columns:
        key = _key(col)
        canonical = next((name for name, names in ALIASES.items() if key in {_key(x) for x in names}), None)
        if canonical:
            if canonical in mapping:
                raise DataValidationError(f"More than one column maps to '{canonical.replace('_', ' ')}'. Keep one and rename or remove the duplicate.")
            mapping[canonical] = col
        normalized_keys[key] = col

    id_col = mapping.get("student_id")
    name_col = mapping.get("student_name")
    if not id_col and not name_col:
        raise DataValidationError("A student identifier is required. Add a 'Student_ID' or 'Student_Name' column.")

    score_cols = {name: mapping[name.lower()] for name in SCORE_FIELDS if name.lower() in mapping}
    # If there are no recognized scores, try a wide table with numeric subject columns.
    if not score_cols:
        metadata = set(mapping.values())
        candidate_cols = []
        for col in frame.columns:
            if col in metadata:
                continue
            vals = _numeric(frame[col])
            if vals.notna().sum() >= max(1, int(np.ceil(len(frame) * 0.5))):
                candidate_cols.append(col)
        if not candidate_cols:
            raise DataValidationError("No score column was recognized. Use Score, Marks, Assignment_Score, Test_Score, or numeric subject columns.")
        id_vars = [c for c in frame.columns if c not in candidate_cols]
        frame = frame.melt(id_vars=id_vars, value_vars=candidate_cols, var_name="Subject", value_name="Score")
        mapping = {name: col for name, col in mapping.items() if col in frame.columns}
        mapping["subject"] = "Subject"
        mapping["score"] = "Score"
        score_cols = {"Score": "Score"}

    # Preserve the source fields in a predictable schema.
    out = pd.DataFrame(index=frame.index)
    out["Student_ID"] = frame[id_col].map(_display_id) if id_col else frame[name_col].map(_display_id)
    out["Student_Name"] = frame[name_col].map(_display_id) if name_col else out["Student_ID"]
    subject_col = mapping.get("subject")
    out["Subject"] = frame[subject_col].astype("string").str.strip() if subject_col else "Overall"
    topic_col = mapping.get("topic")
    out["Topic"] = frame[topic_col].astype("string").str.strip() if topic_col else pd.NA

    warnings: list[str] = []
    invalid_scores = 0
    for canonical, dest in (("score", "Score"), ("assignment_score", "Assignment_Score"), ("test_score", "Test_Score")):
        source = mapping.get(canonical)
        if source:
            raw_values = frame[source]
            values = _numeric(frame[source])
            nonblank = raw_values.notna() & raw_values.astype("string").str.strip().ne("")
            invalid_scores += int((nonblank & (values.isna() | ~values.between(0, score_max))).sum())
            values = values.where(values.between(0, score_max))
            out[dest] = values * (100.0 / score_max)
    if invalid_scores:
        warnings.append(f"{invalid_scores} score value(s) were outside 0–{score_max:g} or invalid and treated as missing.")
    available_score_cols = [c for c in SCORE_FIELDS if c in out]
    out["Performance_Score"] = out[available_score_cols].mean(axis=1, skipna=True)

    attendance_col = mapping.get("attendance")
    if attendance_col:
        raw_attendance = frame[attendance_col]
        attendance = _numeric(frame[attendance_col])
        nonblank_attendance = raw_attendance.notna() & raw_attendance.astype("string").str.strip().ne("")
        bad_attendance = int((nonblank_attendance & (attendance.isna() | ~attendance.between(0, 100))).sum())
        out["Attendance"] = attendance.where(attendance.between(0, 100))
        if bad_attendance:
            warnings.append(f"{bad_attendance} attendance value(s) were outside 0–100% or invalid and treated as missing.")

    term_col = mapping.get("term")
    if term_col:
        out["Term"] = frame[term_col].astype("string").str.strip()
    elif mapping.get("date"):
        dates = pd.to_datetime(frame[mapping["date"]], errors="coerce")
        out["Term"] = dates.dt.strftime("%Y-%m-%d").astype("string")
    else:
        out["Term"] = "Current"

    blank_ids = out["Student_ID"].astype("string").str.strip().eq("") | out["Student_ID"].isna()
    if blank_ids.any():
        out.loc[blank_ids, "Student_ID"] = out.loc[blank_ids, "Student_Name"]
    blank_names = out["Student_Name"].astype("string").str.strip().eq("") | out["Student_Name"].isna()
    out.loc[blank_names, "Student_Name"] = out.loc[blank_names, "Student_ID"]
    out["Subject"] = out["Subject"].replace("", pd.NA).fillna("Unspecified")
    out["Topic"] = out["Topic"].replace("", pd.NA)
    out["Term"] = out["Term"].replace("", pd.NA).fillna("Unspecified")

    missing_score = out["Performance_Score"].isna()
    missing_student = out["Student_ID"].isna() | out["Student_ID"].astype("string").str.strip().eq("")
    missing_count = int((missing_score | missing_student).sum())
    out = out.loc[~(missing_score | missing_student)].copy()
    if missing_count:
        warnings.append(f"{missing_count} row(s) with no usable score or student identifier were excluded from score analysis.")
    if out.empty:
        raise DataValidationError("No usable scored records remain. Check student identifiers and score values.")
    out["Performance_Score"] = out["Performance_Score"].clip(0, 100)
    out["Student_ID"] = out["Student_ID"].astype(str)
    out["Student_Name"] = out["Student_Name"].astype(str)
    out["Subject"] = out["Subject"].astype(str)
    out["Term"] = out["Term"].astype(str)
    if out.duplicated().any():
        warnings.append(f"{int(out.duplicated().sum())} duplicate row(s) are present; they are retained as separate observations.")
    return out.reset_index(drop=True), warnings


def ordered_periods(series: pd.Series) -> list[str]:
    """Return chronological/numeric period order when possible; otherwise first-seen order."""
    values = list(pd.unique(series.dropna().astype(str)))
    if len(values) < 2:
        return values
    if all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", x) for x in values):
        parsed = pd.to_datetime(pd.Series(values), format="%Y-%m-%d", errors="coerce")
        return [x for _, x in sorted(zip(parsed, values))]
    nums = [re.search(r"\d+(?:\.\d+)?", x) for x in values]
    if all(nums):
        return [x for _, x in sorted((float(m.group()), x) for x, m in zip(values, nums))]
    return values


def student_summary(data: pd.DataFrame) -> pd.DataFrame:
    """Aggregate per student, using means over the selected records."""
    agg = {"Performance_Score": "mean", "Subject": "nunique", "Term": "nunique"}
    if "Attendance" in data:
        agg["Attendance"] = "mean"
    result = data.groupby(["Student_ID", "Student_Name"], as_index=False).agg(agg)
    result = result.rename(columns={"Performance_Score": "Average_Score", "Subject": "Subjects", "Term": "Periods", "Attendance": "Average_Attendance"})
    result["Risk_Flag"] = (result["Average_Score"] < 60) | (result.get("Average_Attendance", pd.Series(np.nan, index=result.index)) < 75)
    return result.sort_values("Average_Score", ascending=False).reset_index(drop=True)


def period_comparison(data: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any] | None]:
    """Compare the latest two available periods; no forecast is made."""
    periods = ordered_periods(data["Term"])
    if len(periods) < 2:
        return pd.DataFrame(columns=["Term", "Average_Score", "Students"]), None
    trend = data.groupby("Term", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Students=("Student_ID", "nunique"))
    trend["_order"] = trend["Term"].map({p: i for i, p in enumerate(periods)})
    trend = trend.sort_values("_order").drop(columns="_order").reset_index(drop=True)
    prev, curr = trend.iloc[-2], trend.iloc[-1]
    comparison = {"previous": str(prev["Term"]), "current": str(curr["Term"]), "previous_average": float(prev["Average_Score"]), "current_average": float(curr["Average_Score"]), "change": float(curr["Average_Score"] - prev["Average_Score"])}
    return trend, comparison


def recommendations(student: pd.Series, subject_means: pd.DataFrame, comparison: dict[str, Any] | None = None, topic_means: pd.DataFrame | None = None) -> list[str]:
    """Return plain-language, threshold-based suggestions grounded in supplied data."""
    tips: list[str] = []
    score = float(student["Average_Score"])
    name = str(student.get("Student_Name", student.get("Student_ID", "Student")))
    if not subject_means.empty:
        weakest = subject_means.sort_values("Average_Score").iloc[0]
        if float(weakest["Average_Score"]) < 65:
            tips.append(f"Prioritize {weakest['Subject']}: the observed average is {weakest['Average_Score']:.1f}%. Set a short practice goal, review recent errors, and revisit this subject before retesting.")
    if topic_means is not None and not topic_means.empty:
        weak_topics = topic_means[topic_means["Average_Score"] < 65].sort_values("Average_Score")
        if not weak_topics.empty:
            weakest_topic = weak_topics.iloc[0]
            periods_count = int(weakest_topic.get("Periods", 0))
            evidence = f"across {periods_count} periods" if periods_count >= 2 else "in the available records"
            tips.append(f"Review {weakest_topic['Topic']}: the observed average is {weakest_topic['Average_Score']:.1f}% {evidence}. Use topic-specific practice and check understanding again in a later assessment.")
    if score < 60:
        tips.append(f"{name}'s overall observed average is {score:.1f}%. Arrange a teacher check-in to identify specific gaps and agree on a manageable weekly study plan.")
    elif score < 75:
        tips.append(f"Build consistency: {name}'s observed average is {score:.1f}%. Use brief retrieval-practice sessions and ask for feedback on missed questions.")
    else:
        tips.append(f"Maintain the current habits: {name}'s observed average is {score:.1f}%. Stretch learning with harder practice in the strongest subjects while keeping up review in weaker ones.")
    attendance = student.get("Average_Attendance", np.nan)
    if pd.notna(attendance) and float(attendance) < 85:
        tips.append(f"Average recorded attendance is {float(attendance):.1f}%. Review missed lesson dates and agree on a catch-up plan; this is an association to check, not proof of cause.")
    if comparison:
        delta = float(comparison["change"])
        if delta >= 2:
            tips.append(f"Class average rose by {delta:.1f} percentage points from {comparison['previous']} to {comparison['current']}; keep using the practices that coincided with this improvement.")
        elif delta <= -2:
            tips.append(f"Class average fell by {abs(delta):.1f} percentage points from {comparison['previous']} to {comparison['current']}; review recent assessment coverage and workload with the class.")
        else:
            tips.append(f"Class average was broadly stable ({delta:+.1f} percentage points) from {comparison['previous']} to {comparison['current']}; choose one specific skill to improve next.")
    if not tips:
        tips.append("Upload subject or topic-level records to get more targeted suggestions.")
    return tips
