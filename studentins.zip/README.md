# Student Performance Insights

A beginner-friendly Streamlit dashboard for exploring student marks, attendance, subject/topic strengths, period-to-period changes, and explainable study suggestions. It accepts CSV and Excel (`.xlsx` / `.xls`) files, includes a sample dataset, validates data, and exports a report and filtered records.

## Run it

Python 3.10 or newer is recommended.

```bash
cd student-performance-insights
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit (usually `http://localhost:8501`). Choose **Try the sample dataset** to explore immediately, or choose **Upload a file**. In the sidebar, set the maximum possible marks for the assessment scores (100 by default). Attendance must be entered as a percentage from 0 to 100.

## Input format

The simplest format has one row per student, subject, and period/assessment. `Student_ID` or `Student_Name` is required. At least one recognized score column is required. Example:

| Student_ID | Student_Name | Subject | Topic | Score | Assignment_Score | Test_Score | Attendance | Term |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| S001 | Alex Rivera | Mathematics | Fractions | 78 | 84 | 75 | 92 | Term 1 |

Common alternatives are accepted: `ID`, `Roll_No`, `Name`, `Course`, `Marks`, `Exam_Marks`, `Quiz_Score`, `Homework_Score`, `Attendance_Percentage`, `Semester`, `Quarter`, and date columns. A wide table with a student identifier and numeric subject columns (for example `Mathematics`, `Science`) is also supported and converted into subject observations.

CSV and Excel headers should be in the first row. Excel workbooks let you select a worksheet. Keep score columns on a consistent raw scale within a file. For example, if marks are out of 50, set **Maximum possible marks** to 50; values are then normalized to percentages. Attendance remains on a 0–100 scale.

## What the calculations mean

- **Record performance score:** equal-weight arithmetic mean of whichever of `Score`, `Assignment_Score`, and `Test_Score` are present in that row. Missing components are ignored. A row with no valid score is excluded from score analysis.
- **Student/subject/class averages:** arithmetic means over the currently selected records. Repeated rows are retained as separate observations.
- **Risk flag:** observed student average below 60%, or mean recorded attendance below 75% when attendance is supplied. This is a screening signal, not a diagnosis or prediction.
- **Weak areas:** the lowest observed subject/topic averages; targeted suggestions are triggered below 65%. A topic is called a *repeated* gap in the dashboard only when its average is below 65% in at least two observed periods.
- **Trend:** group average in the latest two available selected periods, ordered chronologically when periods are dates/numbers, otherwise in their first-seen order. The dashboard does not extrapolate or forecast.
- **Reports:** download a cohort report or a selected-student HTML report, plus the filtered records as CSV.
- **Suggestions:** explicit, inspectable threshold-based rules, grounded in selected records. They are not fabricated LLM outputs or predictive model results. Confirm them with a teacher and student before acting.

## Data validation and privacy

Blank score values are omitted from score averages; malformed and out-of-range scores (relative to the configured maximum) and attendance values outside 0–100 are treated as missing and reported. Rows without an identifier or usable score are excluded. Duplicate observations are retained and reported, rather than silently removed. Clear error messages explain missing identifiers, score fields, or unusable records.

The app runs locally by default and does not send student data to an AI service. Use de-identified data where possible and follow your institution's student-data policies. The dashboard is an aid to discussion, not a grading authority or substitute for educator judgment.

## Files

- `app.py` — Streamlit interface, Plotly visualizations, filters, and HTML/CSV downloads.
- `analysis.py` — column mapping, validation, normalization, aggregates, trend comparison, recommendations.
- `sample_data.csv` — small illustrative dataset for testing the app (not real student records).
- `tests/test_analysis.py` — automated unit tests.

Run tests with:

```bash
python -m unittest discover -s tests -v
```
