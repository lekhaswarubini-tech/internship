#!/bin/sh
set -eu

APP_PORT=8501
WEB_PORT="${PORT:-3000}"
case "$WEB_PORT" in
  ''|*[!0-9]*) echo "PORT must be a valid TCP port number." >&2; exit 1 ;;
esac

cat > /etc/nginx/conf.d/default.conf <<NGINX
server {
    listen ${WEB_PORT};
    server_name _;
    client_max_body_size 200m;
    proxy_read_timeout 3600s;
    proxy_buffering off;

    location = /manus-routes.json {
        default_type application/json;
        add_header Cache-Control "no-cache" always;
        return 200 '{"routes":[{"path":"/","title":"Student Performance Insights"}]}';
    }

    location / {
        proxy_pass http://127.0.0.1:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Host \$http_x_forwarded_host;
        proxy_set_header X-Forwarded-Proto \$http_x_forwarded_proto;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_hide_header X-Frame-Options;
    }
}
NGINX

streamlit run app.py \
    --server.address=127.0.0.1 \
    --server.port="$APP_PORT" \
    --server.headless=true \
    --server.enableCORS=false \
    --server.enableXsrfProtection=false \
    --server.maxUploadSize=200 &

ready=0
for attempt in $(seq 1 60); do
    if python3 - "$APP_PORT" <<'PY'
import sys
import urllib.request
try:
    response = urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/_stcore/health", timeout=1)
    sys.exit(0 if response.status == 200 else 1)
except Exception:
    sys.exit(1)
PY
    then
        ready=1
        break
    fi
    sleep 1
done
if [ "$ready" -ne 1 ]; then
    echo "Streamlit did not become healthy on port $APP_PORT." >&2
    exit 1
fi

exec nginx -g 'daemon off;'
