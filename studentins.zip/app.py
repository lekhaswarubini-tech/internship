from __future__ import annotations

from datetime import datetime, timezone
from html import escape
import re

import pandas as pd
import plotly.express as px
import streamlit as st

from analysis import (
    DataValidationError,
    normalize_dataset,
    ordered_periods,
    period_comparison,
    recommendations,
    student_summary,
)

st.set_page_config(page_title="Student Performance Insights", page_icon="📊", layout="wide")
st.markdown("""
<style>
:root { --ink:#172b4d; --muted:#62748a; --line:#e6ebf2; --accent:#2864dc; }
.block-container {max-width: 1440px; padding-top: 1.4rem; padding-bottom: 3rem;}
[data-testid="stMetric"] {background:#f6f8fc; border:1px solid var(--line); padding:14px 16px; border-radius:12px;}
[data-testid="stMetricLabel"] {color:var(--muted);}
[data-testid="stMetricValue"] {color:var(--ink);}
.small-note {color:var(--muted);font-size:.91rem;}
</style>
""", unsafe_allow_html=True)

SAMPLE_PATH = "sample_data.csv"


def load_input(uploaded, sheet: str | None) -> pd.DataFrame:
    name = uploaded.name.lower()
    if name.endswith(".csv"):
        uploaded.seek(0)
        try:
            return pd.read_csv(uploaded, dtype="string")
        except UnicodeDecodeError:
            uploaded.seek(0)
            return pd.read_csv(uploaded, encoding="latin-1", dtype="string")
    uploaded.seek(0)
    return pd.read_excel(uploaded, sheet_name=sheet or 0)


def make_report(summary: pd.DataFrame, data: pd.DataFrame, comparison: dict | None, warnings: list[str], title: str, suggestions: list[str] | None = None) -> str:
    subject = data.groupby("Subject", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Records=("Performance_Score", "size")).sort_values("Average_Score")
    topics = data.dropna(subset=["Topic"]).groupby("Topic", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Records=("Performance_Score", "size"), Periods=("Term", "nunique")).sort_values("Average_Score")
    students = summary.copy()
    for col in ["Average_Score", "Average_Attendance"]:
        if col in students:
            students[col] = students[col].round(1)
    subject["Average_Score"] = subject["Average_Score"].round(1)
    topics["Average_Score"] = topics["Average_Score"].round(1)
    data_table = students.to_html(index=False, border=0, classes="data", escape=True)
    subj_table = subject.to_html(index=False, border=0, classes="data", escape=True)
    topic_table = topics.to_html(index=False, border=0, classes="data", escape=True) if not topics.empty else "<p>No topic field was supplied.</p>"
    comparison_text = "Trend comparison unavailable: provide at least two periods." if comparison is None else f"Average score changed {comparison['change']:+.1f} percentage points from {escape(comparison['previous'])} ({comparison['previous_average']:.1f}%) to {escape(comparison['current'])} ({comparison['current_average']:.1f}%)."
    warnings_html = "".join(f"<li>{escape(w)}</li>" for w in warnings) or "<li>No import warnings.</li>"
    suggestions_html = "".join(f"<li>{escape(suggestion)}</li>" for suggestion in (suggestions or []))
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>{escape(title)}</title><style>
body{{font:15px/1.55 system-ui,Arial,sans-serif;color:#172b4d;max-width:1100px;margin:32px auto;padding:0 20px}}h1,h2{{color:#153260}}.note{{background:#f3f6fb;padding:14px;border-radius:9px}}table{{border-collapse:collapse;width:100%;margin:14px 0 28px}}th,td{{text-align:left;border-bottom:1px solid #e6ebf2;padding:8px}}th{{background:#f4f7fb}}small{{color:#596b80}}</style></head><body>
<h1>{escape(title)}</h1><p><small>Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} · {len(summary)} students · {len(data)} scored records</small></p>
<div class='note'><b>How to read this report.</b> Scores are normalized to 0–100%. Each record's performance score is the equal-weight mean of the available Score, Assignment_Score, and Test_Score values. Student/subject averages are arithmetic means of the included records. Risk flags use an observed average below 60% or attendance below 75% when available; these are screening indicators, not diagnoses or predictions. Recommendations are explainable rules, not generated predictions.</div>
	<h2>Period comparison</h2><p>{comparison_text}</p><h2>Subject averages</h2>{subj_table}<h2>Topic averages</h2>{topic_table}<h2>Student summary</h2>{data_table}{f'<h2>Personalized suggestions</h2><ul>{suggestions_html}</ul>' if suggestions_html else ''}<h2>Data-quality notes</h2><ul>{warnings_html}</ul>
</body></html>"""

st.title("Student Performance Insights")
st.caption("A clear, data-driven view of academic progress—built from the records you provide.")

with st.sidebar:
    st.header("Dataset")
    source_mode = st.radio("Choose data source", ["Try the sample dataset", "Upload a file"], index=0)
    uploaded = None
    excel_sheet = None
    if source_mode == "Upload a file":
        uploaded = st.file_uploader("Choose a CSV or Excel file", type=["csv", "xlsx", "xls"])
        if uploaded is not None and uploaded.name.lower().endswith((".xlsx", ".xls")):
            try:
                uploaded.seek(0)
                xls = pd.ExcelFile(uploaded)
                excel_sheet = st.selectbox("Excel worksheet", xls.sheet_names)
            except Exception as exc:
                st.error(f"Could not read workbook: {exc}")
    score_max = st.number_input("Maximum possible marks", min_value=1.0, max_value=10000.0, value=100.0, step=1.0, help="Marks are normalized to percentages. Attendance should already be a percentage from 0 to 100.")
    st.divider()
    st.markdown("**Expected fields**")
    st.caption("Student_ID or Student_Name plus a recognized score column. Subject, Topic, Attendance, Term, Assignment_Score and Test_Score are optional. Wide tables with one numeric column per subject are also supported.")
    st.download_button("Download sample CSV", data=open(SAMPLE_PATH, "rb").read(), file_name="student_performance_sample.csv", mime="text/csv")

try:
    if source_mode == "Try the sample dataset":
        raw_df = pd.read_csv(SAMPLE_PATH)
        dataset_label = "Sample dataset"
    elif uploaded is not None:
        raw_df = load_input(uploaded, excel_sheet)
        dataset_label = uploaded.name
    else:
        st.info("Upload a CSV or Excel workbook to start, or switch to the included sample dataset.")
        st.stop()
    data, warnings = normalize_dataset(raw_df, score_max=score_max)
except DataValidationError as exc:
    st.error(f"Data validation: {exc}")
    st.stop()
except Exception as exc:
    st.error(f"Unable to load this file. Check that it is a valid CSV/XLSX file with a header row. Details: {exc}")
    st.stop()

with st.sidebar:
    st.divider()
    st.header("Explore")
    periods = ordered_periods(data["Term"])
    chosen_periods = st.multiselect("Periods", periods, default=periods)
    subjects = sorted(data["Subject"].unique().tolist())
    chosen_subjects = st.multiselect("Subjects", subjects, default=subjects)

filtered = data[data["Term"].isin(chosen_periods) & data["Subject"].isin(chosen_subjects)].copy()
if filtered.empty:
    st.warning("No records match these filters. Select at least one period and one subject in the sidebar.")
    st.stop()

summary = student_summary(filtered)
trend, comparison = period_comparison(filtered)
count_students = filtered["Student_ID"].nunique()
mean_score = filtered["Performance_Score"].mean()
flag_count = int(summary["Risk_Flag"].sum())
avg_att = filtered["Attendance"].mean() if "Attendance" in filtered else None

st.markdown(f"<div class='small-note'>Showing <b>{escape(dataset_label)}</b> · {len(filtered):,} scored records · {count_students:,} students</div>", unsafe_allow_html=True)
if warnings:
    with st.expander(f"Data-quality notes ({len(warnings)})", expanded=True):
        for warning in warnings:
            st.warning(warning)
else:
    st.success("No data-quality issues detected during import.")

cols = st.columns(4)
cols[0].metric("Class average", f"{mean_score:.1f}%")
cols[1].metric("Students", f"{count_students:,}")
cols[2].metric("Need attention*", f"{flag_count:,}")
cols[3].metric("Mean attendance", f"{avg_att:.1f}%" if avg_att is not None and pd.notna(avg_att) else "Not provided")
st.caption("*Screening flag: student average below 60% or mean attendance below 75%, when attendance is available. Not a diagnosis or prediction.")

left, right = st.columns(2)
with left:
    st.subheader("Average by subject")
    subject_avg = filtered.groupby("Subject", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Records=("Performance_Score", "size")).sort_values("Average_Score")
    fig = px.bar(subject_avg, x="Average_Score", y="Subject", orientation="h", color="Average_Score", color_continuous_scale="RdYlGn", range_color=(0, 100), hover_data={"Records": True, "Average_Score": ":.1f"})
    fig.update_layout(xaxis_title="Mean score (%)", yaxis_title="", coloraxis_showscale=False, height=max(330, 44 * len(subject_avg)), margin=dict(l=5, r=10, t=15, b=5))
    fig.update_xaxes(range=[0, 100])
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Period trend")
    if len(trend) >= 2:
        fig = px.line(trend, x="Term", y="Average_Score", markers=True, hover_data={"Students": True, "Average_Score": ":.1f"})
        fig.update_traces(line_color="#2864dc", marker_size=9)
        fig.update_layout(xaxis_title="Period", yaxis_title="Mean score (%)", yaxis=dict(range=[0, 100]), height=max(330, 44 * len(trend)), margin=dict(l=5, r=10, t=15, b=5))
        st.plotly_chart(fig, use_container_width=True)
        if comparison:
            st.info(f"Latest selected comparison: **{comparison['previous']} → {comparison['current']}** · {comparison['change']:+.1f} percentage points ({comparison['previous_average']:.1f}% → {comparison['current_average']:.1f}%). This compares group averages, not individual causal effects.")
    else:
        st.info("Add at least two periods (for example, Term 1 and Term 2) to view a trend. No trend is inferred from a single period.")

st.subheader("Topic-level weak areas")
topic_avg = filtered.dropna(subset=["Topic"]).groupby("Topic", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Records=("Performance_Score", "size"), Periods=("Term", "nunique")).sort_values("Average_Score")
if topic_avg.empty:
    st.info("No Topic column was provided. Add topic-level assessment records to identify recurring learning gaps.")
else:
    fig = px.bar(topic_avg, x="Average_Score", y="Topic", orientation="h", color="Average_Score", color_continuous_scale="RdYlGn", range_color=(0, 100), hover_data={"Records": True, "Periods": True, "Average_Score": ":.1f"})
    fig.update_layout(xaxis_title="Mean score (%)", yaxis_title="", coloraxis_showscale=False, height=max(300, 40 * len(topic_avg)), margin=dict(l=5, r=10, t=10, b=5))
    fig.update_xaxes(range=[0, 100])
    st.plotly_chart(fig, use_container_width=True)
    repeated_gaps = topic_avg[(topic_avg["Average_Score"] < 65) & (topic_avg["Periods"] >= 2)]
    if not repeated_gaps.empty:
        st.warning("Topics below 65% in at least two observed periods:")
        st.dataframe(repeated_gaps.round({"Average_Score": 1}), use_container_width=True, hide_index=True)
    else:
        st.caption("A repeated weak area is highlighted only when its observed mean is below 65% in at least two periods. This is descriptive, not predictive.")

st.subheader("Student performance")
show = summary.copy()
show["Average_Score"] = show["Average_Score"].round(1)
if "Average_Attendance" in show:
    show["Average_Attendance"] = show["Average_Attendance"].round(1)
show = show.rename(columns={"Student_ID": "Student ID", "Student_Name": "Student name", "Average_Score": "Average score (%)", "Average_Attendance": "Attendance (%)", "Subjects": "Subjects", "Periods": "Periods", "Risk_Flag": "Needs attention*"})
st.dataframe(show, use_container_width=True, hide_index=True)

st.subheader("Personalized, evidence-based suggestions")
student_options = summary["Student_ID"].astype(str).tolist()
selected_student = st.selectbox("Select a student", student_options, format_func=lambda sid: f"{summary.loc[summary.Student_ID.astype(str).eq(sid), 'Student_Name'].iloc[0]} ({sid})")
student_row = summary.loc[summary["Student_ID"].astype(str).eq(selected_student)].iloc[0]
student_subjects = filtered[filtered["Student_ID"].astype(str).eq(selected_student)].groupby("Subject", as_index=False).agg(Average_Score=("Performance_Score", "mean"))
student_topics = filtered[filtered["Student_ID"].astype(str).eq(selected_student)].dropna(subset=["Topic"]).groupby("Topic", as_index=False).agg(Average_Score=("Performance_Score", "mean"), Periods=("Term", "nunique"))
student_tips = recommendations(student_row, student_subjects, comparison, student_topics)
for tip in student_tips:
    st.markdown(f"- {tip}")
st.caption("Suggestions use only the uploaded observations and explicit thresholds. They are not model-generated forecasts; discuss learning needs with the student and teacher.")

with st.expander("Data preview and calculation details"):
    st.markdown("- Scores are converted to percentages using the maximum-marks setting in the sidebar.")
    st.markdown("- A record's performance score is the equal-weight mean of the provided Score, Assignment_Score and Test_Score columns; missing components are omitted.")
    st.markdown("- Student and subject means are arithmetic averages across the currently selected records. Repeated rows are kept as separate observations.")
    st.markdown("- Trend compares the latest two periods available in the selected data. It is not a forecast.")
    st.dataframe(filtered.head(100), use_container_width=True, hide_index=True)

report = make_report(summary, filtered, comparison, warnings, f"Student performance report — {dataset_label}")
student_name = str(student_row["Student_Name"])
student_records = filtered[filtered["Student_ID"].astype(str).eq(selected_student)].copy()
student_report = make_report(summary.loc[summary["Student_ID"].astype(str).eq(selected_student)], student_records, period_comparison(student_records)[1], warnings, f"Student report — {student_name}", student_tips)
safe_student_id = re.sub(r"[^A-Za-z0-9_-]+", "_", selected_student).strip("_") or "student"
st.download_button("Download cohort report (HTML)", data=report.encode("utf-8"), file_name="student_performance_report.html", mime="text/html", type="primary")
st.download_button("Download selected-student report (HTML)", data=student_report.encode("utf-8"), file_name=f"student_report_{safe_student_id}.html", mime="text/html")
st.download_button("Download filtered records (CSV)", data=filtered.to_csv(index=False).encode("utf-8"), file_name="filtered_student_records.csv", mime="text/csv")
