import unittest

import pandas as pd

from analysis import DataValidationError, normalize_dataset, period_comparison, recommendations, student_summary


class NormalizeDatasetTests(unittest.TestCase):
    def test_long_format_normalizes_and_averages_available_scores(self):
        raw = pd.DataFrame({
            "Student ID": [1, 1],
            "Student Name": ["Alex", "Alex"],
            "Subject": ["Math", "Science"],
            "Marks": [40, 30],
            "Assignment Score": [30, None],
            "Attendance Percentage": [90, 90],
            "Term": ["Term 1", "Term 1"],
        })
        data, warnings = normalize_dataset(raw, score_max=50)
        self.assertEqual(len(data), 2)
        self.assertEqual(data.loc[0, "Student_ID"], "1")
        self.assertAlmostEqual(data.loc[0, "Performance_Score"], 70.0)
        self.assertAlmostEqual(data.loc[1, "Performance_Score"], 60.0)
        self.assertEqual(data.loc[0, "Attendance"], 90)
        self.assertEqual(warnings, [])

    def test_wide_subject_format_is_melted(self):
        raw = pd.DataFrame({"Student_ID": ["A", "B"], "Math": [80, 50], "Science": [70, 60]})
        data, _ = normalize_dataset(raw)
        self.assertEqual(set(data["Subject"]), {"Math", "Science"})
        self.assertEqual(len(data), 4)
        self.assertAlmostEqual(data.loc[data.Subject.eq("Math") & data.Student_ID.eq("A"), "Performance_Score"].iloc[0], 80)

    def test_out_of_range_values_are_missing_and_warned(self):
        raw = pd.DataFrame({"Student_ID": ["A", "B"], "Subject": ["Math", "Math"], "Score": [50, 101]})
        data, warnings = normalize_dataset(raw)
        self.assertEqual(len(data), 1)
        self.assertTrue(any("outside" in warning for warning in warnings))
        self.assertTrue(any("excluded" in warning for warning in warnings))

    def test_missing_identifier_fails_clearly(self):
        with self.assertRaisesRegex(DataValidationError, "identifier"):
            normalize_dataset(pd.DataFrame({"Subject": ["Math"], "Score": [90]}))

    def test_all_bad_rows_fail_clearly(self):
        with self.assertRaisesRegex(DataValidationError, "No usable scored records"):
            normalize_dataset(pd.DataFrame({"Student_ID": ["A"], "Score": [None]}))

    def test_student_summary_and_term_comparison(self):
        raw = pd.DataFrame({
            "Student_ID": ["A", "A", "A", "A"],
            "Subject": ["Math"] * 4,
            "Score": [60, 80, 70, 90],
            "Attendance": [90, 90, 90, 90],
            "Term": ["Term 1", "Term 1", "Term 2", "Term 2"],
        })
        data, _ = normalize_dataset(raw)
        summary = student_summary(data)
        self.assertAlmostEqual(summary.loc[0, "Average_Score"], 75)
        self.assertFalse(bool(summary.loc[0, "Risk_Flag"]))
        trend, comparison = period_comparison(data)
        self.assertEqual(trend["Term"].tolist(), ["Term 1", "Term 2"])
        self.assertAlmostEqual(comparison["change"], 10)

    def test_topic_recommendation_uses_observed_period_count(self):
        student = pd.Series({"Student_ID": "A", "Student_Name": "Alex", "Average_Score": 70, "Average_Attendance": 90})
        topics = pd.DataFrame({"Topic": ["Fractions"], "Average_Score": [58.0], "Periods": [2]})
        tips = recommendations(student, pd.DataFrame(), topic_means=topics)
        self.assertTrue(any("Fractions" in tip and "across 2 periods" in tip for tip in tips))


if __name__ == "__main__":
    unittest.main()
